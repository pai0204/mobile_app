import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart'; 

class Page4 extends StatefulWidget {
  Page4({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page4State createState() => _Page4State();
}

class _Page4State extends State<Page4> {
  int likeCount = 0;  // To keep track of the number of likes
  int dislikeCount = 0;  // To keep track of the number of dislikes

  final youtubeUrl = "https://youtu.be/id_OPAvAuMc?si=YM-e872EsANLICNR";
  Future<void> _launchYoutube() async {
    final Uri url = Uri.parse(youtubeUrl);
    if (!await launchUrl(url)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor:Colors.green[100],
      appBar: AppBar(backgroundColor:Colors.blue[100],
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // Add padding around the content
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center the image
            Center(
              child: Image.network(
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFhUXGBcXGBcXGBUXFxcWFhgXFxUVFRcYHSggGBolHRcVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGzAmHyYtKy0tLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAMoA+QMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAEBQIDBgEABwj/xAA7EAABAwIEAwYFAgUEAgMAAAABAAIRAyEEEjFBBVFhBhMicYGRMqGxwfBC0RRSYuHxI3KCogcVFjNz/8QAGgEAAgMBAQAAAAAAAAAAAAAAAgMBBAUABv/EAC0RAAICAQQBAwMDBAMAAAAAAAABAgMRBBIhMUETIlEyYdEFgfBCcaGxFCOR/9oADAMBAAIRAxEAPwD6+CuyhsxlSzqcABAK8CqWOUg5Tg4tBXmlVhy9mXYOLCV6VCV4BccWNXZUQFIKCTq8SuKJKhtLslLPRJeCjm6KNR8BA7oLyF6ciwBeQlPEu0LR6FXCrzBHz+iGGorl0wpVSRcVwKNN4dpdWiAm5QvDyVFRKucFU5q5M7ANWQ1QomsUNVCIgX4l6WVHapxiAkOIecxUkFFWsQeaoqVgUQ+mTCCfh7mULigk2CYlgSfF4UFMK5iQlYxczyQOISkJ8XhIS19NPq+JYQllaDoUOA9wi4gyI81WjOKN8M9Qg4XBI/UofdTmVxoCkCnlUmxSJXsy8HLiTwKmFxdaFxx0FemAuEqUrjiTVKVCVZRbN0EnhBJZLGt5qmrWEwF3FVcoWRo4PEHEmoT4CZ122ss7U6hxailll7T0Kabbxg05rIF2PDSQfcXQvFOIhluuuwH7pI/FEksaZzFZ9+qaliJco0m5ZfQ4fxcn4G7xdFYbiRIuEjbVaAGt1m9+XNXUsewEjbmkwusTy5Dp6eLXETQtxEqVLGDMGn368iltDFNOhVxaHa+60Iaia5iyjOldNDolclK8Dii05HGR+k/YpmtCq1WR3IpWVuDwyD2AoSrh+SNKiU5PAvAmrU+aV4nD3Wnq0wdUBXwXJGpIFxEtSlACWYimcyf4hh3CCq0LyiIMhjqDs6Fw+B8Jkbla3E4UaoL+G2UeDjJYvhbcrrLH4zDuaTlK+nYjDLOcQ4TJJQ4DTMHiMU6C13uod6m/HOGFrSY0SCUDQxM/V1J6mHKikrqYTiuXNuugL2ZRlQcWtKnKqa1WQuJPALzrL0qrEPygu5KG1FZZwQCr2OgLHu4sadWoZmWn3/SUTguPZaBLzmeNBzB69LrLl+o1y+3f+BsF8j3EOlB16waNUFV7Q0QG5icxEkC+XzKVcV4sX5A0QC3MeYJ2VK7UJJyT5L1Li5KLYvx1fORrre9iSdeiZii0DwgTGqTCrldOsWjmnBqAtlukeiqUJPLZuXLCio9CepLSXcyY8t/zoq21DzUsTUJNxptyUGstJ8hprulyLKaS9wdgsTBWhwlQuHRZPDm60uAdYKaZYlgo6uCxlBr22CP4biZzM3bB/wCJ0+6AFwiuGOh5G5aD7H+61dK2rFgyrknBjIqJXcyiStUziJVblYVArjimpSB1CX4nB8kzcqnKU2jhFiqcC6Cc1aKtTB1CVYrBfy+yNSXkFoR4tqXYqknFdmsoOoyyJkGX41g81Nw6H6L5llX2TGUpC+c/+p6IGhkWfotr1MOSPgHaOhiQMph+7T9k8BTmsFdSyWiVY1VNKlnQhF0r2ZVZl0Fdg4tzIHi2bISDb9Q6cwj2UiegUq+QMdJAEEEu0va/RI1EVOtxyEkfPcTPPe/QHmvcaxVNlNkmwbBI6knbzCX8ao5XWMskQQZBAmHDok+JxUgscSRF4kG+kc15j0OQ84CuH1nEkNdmptuDrM+d/RM21MzpJ80pp16LKbGUjULo8Yc0AAk6Tvb6LuIbWZGem6mCR4ntc0Sep9VNlTchkFJvhZGrjma50Wt6bIjCuew5TYcvNJcIQ54Gc5ZuTIH/ABby81pK76bbueHeQufTdAoSj0b9NsaKlXa1nl47x+AOq0k+ZQXEMbcMabAR5k6qXFOKNygU9TMzslDc0F0gxrcT8tkUYPtlPW6r1Wow6Q44XXAe1oi5uTzOwhbnA8PdyI3vZYvsZTY6p3shxpk+BwtJHhcHTtfZbw8SKsU1VZzN8i4zt9NRQXTwIAuZUxhGclVh6+ZFArXrhXj2opzlNPlkW4do0aF5wO3srQFwpu1LoXub7AKmPAMEFebiwdLpdiKxzuI3KBxFQu8JiOg+6zJa6UG88l+OkjJDvGY0U4zB0H9QEtH+6NFNtQOEggjosrj6MgePxHTU6bHoo4Ou+iC1pAmDcSAVMf1JKWJrCCegThmL5NS8qioo4TFB7Rpmi46/suvC04yUllGbKLi8MCxVAO1SPF4YtPTmtDUQtZso1LBGDL1xZJf4Qclo+JYbLcafRLMqYuQejK9lKtRtdhYCbhfb2ExfVYnsjw/uYzAE7dFse9VifwVYPLbCMxXc6HYXEwEbToR8Rk8h90ptLsclklSYSiGNA6lV96uF6RKY1Qx2EZ0m4/xSk2m9ktc4gjKbi/8AN5IXinFi0Qw5SSBmidQdvZYDiGJLiIflzHz91l36vPtgOqlX/Xn+y/IdTxDRSdTqZTBJplt/DElp5GSfRLGODhY+ipwtVjBUfVdmMODeZOlgOpCDxnFMghgDjYzNgDcC28Kpsk+EMdcbZ4pXH3C8ZUNMZmiTIiIkX1E/llJjn1nd5Vc539TySfIDQJVg8c6sQ98QPhA08zKuxmKiBGvysi2SXt8kwvnXFwh35f4Y1pY1gfkbyJnlGinUxYiVm8Nicr8uzvqBz5ao7CjPVa1wlurgJ0idusIZVYAqplOSXyG4ylUc2Q3lEiJB3B3VWD4bU7y/wg8zdp1iE+qP0tAAgDkBpC9SbJVf1mlg9BV+nVxScg7BYltNoaxoA/bnzTLDYidNOSTihGunujsA43AGp9khS5HW1w2+00OBeSRHRaCm1KODYL9RunQW/oYSVeZeTzurknPCOFA4/EwCAp4vE7BKcTUv5qNVqcJxiRRTl5YqzuAgnc+yqdUVHEsQM+XkJ91AVF59tm7GHGSLpJBV7qgi+qG70aIWtWIUoNwyNKVYtIcCnlHEB4nfcLMYateNk0wNaHDr+BaOhvcJbX0zN1lOVnyhi8oaoVfUQ1RbhkguIbIISn+BHNNqqohcnghoZYbDgJnRwv8ANYct1yjTazS55n7KZenTt+BUay5rgBDRAXJVcroKS2NSLWldcJEHdVhVPxrA17pkMJDtdQAY+Y90MmkuScGN7VViwgXEEzJvGx+Z90swoktNiBpPPn5oXtHjMxLjMkk+6YdjsOSJdABuBrI6LBUU1lAoVdvuBmlQZimhjQP9NwH6u8NrbkRPr0SHCYVr6DSNHNieR8lve39RrqVCm0gtM1PaA0xt8R9lgDjhSdkaJaNRv6KzFvaox7Rs/pkYwUrLPpfAsdX7pxaNkZhK76oJP6Wm53Nv2+aa0sDTrBtTZ1gHZZ+6fcL7Oz8UCnY2N3dOgXT1EEuuSy9BWpubax4S/wAGf4Pw9zzpPI8rLSYPhBDpy+KInoE8fRyiGsgCAPIaXXCxzxAdHOJ+yzrNQ5MfTGNa4AqrWskRmebG9mnpGpUKNImE1w3CDqU1w3BwVEYTnxFBT1cK12J6WFL4DQbak81peE8HDblH4Ph7WDT0/dFVazW6n0Wpp9DGHvsMfUa2Vnth0TEAcggsVjRoEJisYXIHvL7Rr18lN+sX0w6FVafzIvfWvdBYt6nVqj/KR8ZxJ+Ft9zG1wsyyblwaNNWWB1nuc9zoNzyOmkLjw4CYP39tVPB1zeT6bomlVJP5skvGS88oTuxE7HrK5UkwP2stDlaLwC7r+0KL8M6paBlAJmRbpPNOjHPCFO35M6yZAnT6J5h6thzBCGqcNMFzYPQxJ6/NTwjTnDSIJj7JkU9yF2yTiaV5Q1Qoh6GqL0Z50HqKlXVFUoONAFIKsFSBUkFi6CoAroXEljUsxVIvFdjdZY7z8It/1TNqzvEuMsp1qlIHNVf3bW02/EQGkuP9LfEPEdFX1CTg0/v/AKG1QcnhfzkynFeEHNncZHKZ2JTngLWhjSSQackHoCBCjjsKQzxAZnGGgXyga/YeqDq1u7aWioGSIiC7zsFg+o0tpKok3tSMX2k4oamJrVATBMC+wtA6TPuq+G8Gr1ogSCbyYHmSVoMHgMKJEGo8/rc0WJ0LWGQPWbpzVwha0gOdpAJN/TYeisy1KglGK/8ATU0+j2/UzJuY/vqeHyjwiCRdua5IB30C+lYagKbBmMmAAAF8ro4o0MS97XCqKZkh7WkuMGTptqDzC+w9nsbQqU21JkuE3v5IrKlNpZS/uNsslGOcZPYbAuqQX6fy/umtHBQLAIgYpg3Cg/iTBunQ09FazKRnzutn0i2lgxuiZa0bBJa3GxoEBV4oTv8ANTLWUV8Q5IWltn9Q8xPEo0BSrEYmbkz05pY/Fzvp1VffeL8hZt2rnY+S7VpFAYF5+yrqVYQtTEQFn+Odo2UgWth1Q/p2HV3TolRUpvER8ahjxvjIot2Lj8I+56LL0sY9xzOJOm3W6UCu+q/NUMk77RsANgm2FZEEKz6SrWH2W60orgd4So0RFsxRjXX8uSWYB8uToOlsbKpJYZ02d7zlf2IQ+Mkukgeg+ZXKk8uitjST/hcm8CsYeSNOUXh6sEOIkhVNg8l0WvtumVylGWUItxJYY3pVw4SPUclCoErLy3xDUI/D4kVGzvuORW9ptUreH2Y99Dhyuit6qhXPCqVsrDoFSBVYUwVwJYEr7Q8ebhWglpcToBYWuSSr+K4s0qTnNEu0Hmdz5XPovk/F+O97ThxL6hqZi5wIhgEAN2uZ9Ak2WY4XZf0mlVnvl18fJsz2zqVnU6WHDQ+rYTLst/iPkJPoiuGYdjCSXZnvqPaarozODXZfaWugJJ2HwRw+Gq4ru4qV3CnQBnRxgETcAk+oYFp8UxlINa0TkAbJ/pufcySqGreK8yZbqSU9sUQxeGLZg3dJB1y5tSOsBLncJbUpEg+MGCTPLflunfFapDA5osWjTWCgMMblk6zfn+6zJLEmh0Flb/ImwfC203d48iRccraT813DcVZWxGSYDQcswA47/wBkN2lw1RjtS5jyY1tYW+vsstUYQZ0I+33sm1171mTLP3Q/7QcAtUqMYZyuMN/Vvcc/JZXs12ndhj3bj4Nv6f7JxxLjVWmxrRUM2BJubjTmsVXw73ODWtJJ0AG/Iq7p698HGzor3zlBpx7PrmF7QNqNkOB9Ve7iQjVYLgvY+u1pqVnuoAEgUwAajzlkBt4F41HNMuFcBxbmjvHhu9gT8yqVunqi3iY+qzcuY4NM7iA5r38c1Kv/AI64m9R0c7D2EK2l2ac45Q9xOuuw1SdlfWSxlBzuIDmh8VxylTEveAOu/kN0vf2ceQQKr/8Ar9wkmO7FVDdrnF39ZBB53AkJtdVDfukLslNL2xyT4v2we+W0fCP5jr6DZJsOSTJJJNydyeq5X4HiKR8VJxHNoLh7hWYW2o/Oq0lCuEf+srwlNv3DrAU5TOk6LbFA4CmYJB8vumTKctEjyVC18lxdBuGGUTKN/idwgcKBboji0bKpLshhtFzSJ/JUO+nX8HVU4XQjW65UUCsLJdlmFcaci6qo6KzvdkUfuJsz4IO0gqnDVRTqAnQyD5HT5q9zpEoLEC/ROhNwkpLwIa3JxY9eq4UcFUDqYPKx9FblXo4yUkmjFlFxeGMgphYrhvbtjrPaGmObo94Kd0+1NA0y8fFFmm0k6XOgJ3UerD5HPSXL+kQf+S+KuaGUWmJlzuoEAX5a+yT9k+zgrO7+uMuHp3M6PIvl/wBo39uaCwWFdj8aDmllnVXaBrdXtBO8mBHOU945xwmaLaeTDsBAAkWAlriQeUW6qpOePe/2Neqt7VTD93+PuNMRxsVsbQps/wDrp5qkREBrXAE8r5YHUIipWc+REnWdkB2Y4U6lSNWuIfVg3PibSAHdtP8A2PqEeyrlfzzAx0uszVyk5bWFSor6fHC/YIOJhlNs3ZYnmNj+ckh4zi3YchzSIL5aNABFxPL90ybhz8Zc0NuHDfnJcTA/slvHsA1wptDrQQDci9z90iLzLMv5wOrUU8L7ksVWNXC067jAbUdJkCLlo16mEoxWAhucCA25cdOgPXT3QlXEV8KS2fDrlMlhPOLXsNFrOF1zVb3bw2e7zObBtmiQZJteE55hyuiejNUuB06oYariZ8XhMEg35b/ISVrcLgWA95Tw7aRsM0NJgWkWkFWU6DGCwGbQugSfVT761jPTrokyvlLgFpPnAPXcAZdc8zM+6g7FyNbdDZD16ZJMucN4tc8rIdwIEHQ+SVtHpLAXUxUECZmOvoOa5VxhBBAc0gSDpe8H5Kv+Fb3YcXCWm4JIcTIiL+EeQVzcS1rBlLi+d5OvxHkRBTlVFeQd3wiIxxzZiNToNz6JjLSOvVJMXUgT8vLRTptkNJqa2gDTp1KDZnkJpceAt4zAwfulPFOz7XkubZxHoTz801wvhaWgWGhIj0RbmiwQRnKD4JbMFhwaRg6j77JlSxJgTomHGuH5xIjMN/qJSLDAm0+itqSsWTuhuKwBsiWGeiCwtIHoiqrwLwkSXOEcMu9EAIdjj7qD6oIH56Kqg+BAIlCkLDhXgdN1KmY9fuhGnr5oh7t+UR6KcASRNz7qrEOURiZOkKvEFEJa5GnAvgd5pih+F0stJvW/vp8oROVei08dtUUzEvkpWNowXGuH4WJZUa7k1sZ/SBf1S/EhlOhPwuILZcJc4Rc+QkInF9nqlITnIA3bTt5kh0qeFkYdtXwVKlF8eIZhBMgwfyyqWZysrCNiqcIRxF7jJVa4oRDHgkBwzyA6Y8QGhBjZPOzdWs6tRqP8RbctPibkGgIO/LkYWgxNR2KpZiW5jqMgcyBs5rrHnbRDcDwBoOyU9LOe5x11hrW8tUmy+CT29hRU5Lnr7Ghx2IqEg5fiJvqAdAXEcuSUcRxQDct85nMfL6L2MrVmtJa830kRB1kwNUE/A1e7zycw1m4POFRis8sfFJEezE1HvpglxcbgnwNZYOdG7rfJN+JlzCIIOU5gCBt0VfC8tIU8gALrnq97dz6tb7KvjD6hBblhxkdI6ldN7p8BLOTuJ4izF4aWuBr0+UZswPhIb1TbgXDv4eiATL3GXuJkkm8TqQFm+xmDz13PcbU+QiXGRsLgQVr8Q+3LSPupue32rrsVjnBVVxALtIHz9VQ4wN5FvMcvNTybRG4/yo1COe6q5HJLpFNTxGSV58aeqsbTjUz+3JdNO07fNdkMGwWFzGqXZcoi8XB1sieJV2lrQ2QGnLB3aQLj2QvD64Y85RIdYzpZEVGSNBlkXKsOfhEOPuyzO1q7g4ty3kRNrbH6XTPAtIaXOZBmzpuDv9TdBdoMSDXaymczAAxzYs2P1sdz2I6JxQw8MbMnlPL0TLls4DjJNZwE98SNA4xz5az7/Jde4hocY6jkvUqYAMadOfNeoAEZSFTYPBBtPMSI+JZrGUzTqHkfqtRRqBrxE8rpX2vgMDoGvsU2p84+SHLnAFh64IVpdZJcPiUbTxCbKvBGQ8iwhSw4uVQxytpPAS8AthkrqqZWXH1gSpwKyWvbFyqq9Ub/AOUJjeINZF56a32CS0Mc+tWJNhMNHlv1KdXS5c+BU5cH0XhlbM1HIDg9EtYOZR2Zb0MqKyYc/qeD1ajCTYzCsDtAM0TA1haKuzdAYqg1wk6j8uk6qDnW0hummozTZlsW3McrCG2kbAdVRw2gWvc+tUDgGjUWEGQZ03Ku4vg5cXAtaisHgm1aYNSHARmA0J0k81iqPOEbbmtuWXulzYEXgzNzO8oPHNc1pa4kNAi2pPIc0bTqBrHRZo3PK6z/AGmNao5jqbXOZDTA5nWQphLPtRCXPIC/iLmD/TkbAiJBgC0jUdVRR4pUDXiq8ut4XH4r6gwI9fNA8dcabWtEB0zGsDmepP0Sd+OeLGD8irddClEKdqTPovYqoG0Xub/MRMbAD7k+603dB+87rJdiHF2Enm55HoQD56FaLh7ydLQYWfdxY0/k7uO5Ha2k7KDacWKnXpkEwbfJUlxtOqrsdHokQFQ4l0zyKKyiEPiAItf91yCiwLuxb3urMZWilF9PSfJcos2J8lfiKGZgvpNvPZGnyNyuMiTg+G8Yk2Bzcx1t7J3WxHisJaNOiDwzSzw2nfyRNakNdt/JHZPcyWlnJxuOAsdPp/ZEU6od4tNvPdANriTDQGxy3UaTxmaYLQZB5em+6FxBaGddwkGLpF2qx3+g4uFokdL2+cJtXfcH8hfPu3vEMxFJrp/U8D0gH1unaSp2WJCL5qutyKcNxNvMIxnFmjcLFBhUgwralpYPyZUdZP4NyOONH6lH/wB+3WVi20j1V1PDEoP+JWvIa1Vj6ia53aQKp/HS4HxAfVJsHgHHVNsNwHMQSgcKYE5tYIA6obyVq+zXDSHBxFhzRPCOCaWWpoYUMEAKak7XnwKut2rauwxlS35ZcyqoPhXK+ZzGjm2g3CGNKOoP5dIeE9pMpbSrSZbObl0d+61DYIltwUUotdi4y+BVXwFN1i0ICrw1tNlRrZa1wtqYPknz6XL2/ZVkSIKqz08GnhYZahfJeTC8Q4m0AUgZAABvBkCLhD1MW51PKLOF2gn4xuLbj5rT8S7PUK3xNh3MWKynGezuQx3hcRBaNCORtvZZtmm9PmRq06iNntXYh4jjhkcxzTLmmLbzv1/ZZtgIuR8rLZ4bAuqvJqNgtET/ADzofS6B4pwM3ym+yfTbGPtCtjnkZ/8AjziI7t9K5LTmHLK6QYHn9VtMONNmz5Svl3ZupVwtXO8HKQQ+QTA2dbWD9V9Lwrs4DmnwEBwvrIsqOthizcumFU/ZzwWY2sNBt80K+oddB81ZiHNhD1KkqmWYLghVJIN1yk60GQqauYa6LpqEDT3RYGFtMG/L82VveZWl3y1KGfUI00I5jVVE2u4x/aIU7fklF4DpDiI5Ty0RtMgevNLaNc2uTAt+FSdVJOtyNP8APmolELGSNXDlrpB8J2G3OF79QAi37anmeqk6tlH5slmO4xTotl2pmBuTyCZBSlwiZNJZZHtRxA0qMB3jdYXv/u9vssCKBJk3J3O/mrcRjH1nl7zc6DYDkEThaa2Ka/Rhjz5MycvWlnwUU8GrW8OlNaFFFva1jS51gBJKGV7zwMVEfIrw/Ded0xw3DRyVuHxDHCWmRzCOw7w25B225qvZbMaq4pcFmD4cAnmB4fOyng6CcYVkJNEXdPnop6izYuCVGgGhcqOVjyhqjluqKisIx223lnHOVnelDhX92eqkhmVoDO6qY0OWdzAEfUprS4wcLlDrtsCOU8kq4UfC/wD/AEd9VT2r+MeY+6uYy8MpZwsn0jBYtlZoexwMqx7fdYbse8ioACYym3kRC3r9EiccPA6EsrIE9iorYZjruaCUdU0QpSZQUuGh8ZNcoCr4AEeARGw99El4jh2sMlhJjybPXdaZuoVlcWVO3SRk8p4LVWplHh8nyTjWJc4mWgWjS0TNvzdVcF7RFjm0qhhgsDyGwWp7R0WyfCPYLBcZYAbAJMa4yWxo0Fa2tyPpX8Q0snW/1Xu8EWWU4C8mg2SdvqmjXG1+azZ1bW0XI8oYVKn8yCfiNdxy80PVN/QKo6j1+6mMA0TNIXh9heLx7LwxN5j02mUITY+YUpTdvyMDWY1oFxB2HmoniF9QI5oF4tO8FIsfUOU3PujhQpMCU9qyNOJceBdDb2/JKR8Trd7B0v8ADrtrKDZ8PoVbh1oRpjV0UHbK3h9HsPhTsmuDw53UcILn0TWgEm2xliutInQw6OGEDmkOHh3nSFZhhoj6SzrLGNYPhOGsAAaBHTRNKHD5hX4UJrQCmit3S5ZSvucFwUUcJCIiFY5UOW5VRCtcGRO2U+yL3Kh6sK5S1ThZOjSi5VmZSqoWVIJ//9k=',
                width: 300, // Image width
                height: 200, // Image height
                fit: BoxFit.cover, // Ensure the image does not stretch or distort
              ),
            ),
            SizedBox(height: 50), // Space between the image and text
            // Text describing the steps
            Text(
              'ไข่ลูกเขย เป็นเมนูอาหารไทยที่มีรสชาติกลมกล่อม เปรี้ยวหวานเผ็ด โดยใช้ไข่ไก่ทอดกรอบราดด้วยซอสที่มีส่วนผสมของน้ำมะขามเปียก น้ำปลา และน้ำตาลปี๊บ นิยมทานเป็นกับข้าวหรือของว่าง เป็นเมนูที่ทำง่ายและอร่อยมาก ๆ ค่ะ ',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          
            SizedBox(height: 20), // Space between text and buttons

            // Like and Dislike Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Like button
                IconButton(
                  icon: Icon(Icons.thumb_up, color: Colors.blue),
                  onPressed: () {
                    setState(() {
                      likeCount++;
                    });
                  },
                ),
                Text(
                  '$likeCount Likes',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 20), // Space between buttons

                // Dislike button
                IconButton(
                  icon: Icon(Icons.thumb_down, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      dislikeCount++;
                    });
                  },
                ),
                Text(
                  '$dislikeCount Dislikes',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 20), // Space between buttons and the next content

            // Center the "Open Page 1" button
            Center(
              child: ElevatedButton(
                child: Text('เปิดหน้าที่ 1'),
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
              ),
            ),
             Center(
              child: ElevatedButton(
                onPressed: _launchYoutube,
                child: Text('ดูวิดีโอ'),
              ),
            )
          ],
        ),
      ),
    );
  }

  // Method for creating step text
  Widget _buildStep(int stepNumber, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Text(
            '$stepNumber.',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
