import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page8 extends StatefulWidget {
  Page8({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page8State createState() => _Page8State();
}

class _Page8State extends State<Page8> {
  int likeCount = 0;  // To keep track of the number of likes
  int dislikeCount = 0;  // To keep track of the number of dislikes

    final youtubeUrl = "https://youtu.be/CviwWu6fCmU?si=tcmfPBM4h15zNl8g";
  Future<void> _launchYoutube() async {
    final Uri url = Uri.parse(youtubeUrl);
    if (!await launchUrl(url)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor:Colors.green[100],
      appBar: AppBar(backgroundColor:Colors.blue[100],
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // Add padding around the content
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center the image
            Center(
              child: Image.network(
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMVFRUXFxcXGBcYGBcXFxgXGBUXFhcXFxYYHSggGBolHRcVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0lHyUtLS4tLS0tLS0tLS0vLS0tLS0rLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBFAMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAEAQIDBQYABwj/xABAEAABAwIEBAQEAwQKAgMBAAABAAIRAwQFEiExQVFhcQYigZETMqGxwdHwB1Ji8RUjM0JDcpKisuEUUyRzghb/xAAaAQACAwEBAAAAAAAAAAAAAAACAwABBAUG/8QALhEAAgIBBAAFAwQBBQAAAAAAAAECEQMEEiExEyJBUWEUMnEFgaGx0RUjM5Hx/9oADAMBAAIRAxEAPwCNhRDHIKmiGFYkdFhQTwVAwqQFHYNEoKVMBTlCh4KVMCcFZBUspAlUIKEqRdKhBUspqdmUIckXErpVEo4lcuTvhmAYMEwDGhPLupdEoYuU5tKkkZHSBJ0O3NDlVuT6ZDiE0riUiIh0ppToSEKWShi5OhISqsiQ1yYU5yaSoWNJUbk8qIoWWhjionKV4UL0LDSIKrUK9iJqFQVAkyRpgwV7NVyeSuQjLLRjlO0oVhRDVpMLCGFShDtKlDlYJM1SKFilptLiANyYAV3SIKnBWIw4O8jd2jzP68uyrnsLTB3CRh1EMtqIc8Th2TUaD3/K1zuwJS1Ld7fmY4dwY90bgeIFn9WGzncOMROhWuMfKErLqZY5U1wLo8/BTpRuNWnw6mjSGn2noq9aoTU47kSqHSuzJqUBHwVyKisOtviVGt4Tr246qTDLUF/nBDQJiNzyWgo1m7NAHQQFg1WujjexdjI4m+QdtlSY5xyAyIg6gcyOqIpvADWtAAbsI489eKlr+USfdVH/AJJLtNlwM2bJuVybNWPEpq0i9FxP4qGqWuAzMaYMtkBCNqBcTy1TYyy9pg+EhbnDaDg7yw4xBHA9tlnMQoCm8tEkQNT9fqtV8GACZQle0pl2ZwkgRHD2W/T6qUHc3wKeNPoyspCUTfW+R2mx1HZCrrwmpxUkKcWuBFxKfSpOcQ1upKZVplpIIgjcK9yuiUxhKbKUlMJUIIUxxTimOVFkbionlSOKiehYaIapUDip6igeEDHRIXBckc5choZZYsapmlQgqZicZWTNKlaVC1PBVgkwKnta5Y4OHD8RCFBT2qNJpplJ8m5wy3DqTGxBd5nc4OoHeENiVjSfUDSC0CBmHEJfDjXtZ8R7jGrQ0iNABBndWdWnFMu3Lua4c08Uns7X9eiGqW5+b1/sEqUaDG5WtaesSffdTWl4CIG/FVl1Re1skbidEFhl4GPk8R7FYZ6icsi3cI0x08XB1yXuK2mZmUGDx0n+SpbfDGnm6OsfZaFtXy8yUK+wgkgxA1A0W155wXk6M8EupENOzpUyMzZ6xp9d0TWt2RLQIjRKbpj2ZDoRpBQzK+RhETB+6RLO27btDFjftyCf0qxvkAAzCDO4dCbYYgKr6YnzB2Ujpz9pUF5hnxXTmyg68zKH8LYc1lwM2bM3NB2GmhPXce6Upb/uNbjijjbXdGsxL5HBo1gxy2WTolwOvqtfdvBBWOxSuGP36dI/BDmgpStCtE3TQVSquc4NA1K0NnbBgB3dxP5BVvh+nmkx/JXVUQEzDjajYrVZLltRDdOGU69ZCraIDtSJnqkuqxc7INgdfyRHwgB+KKDcpcdIpR2Rp+pVV8OYXDUgaaTIA6Tsr3D7Wlkyta0t46TMd91SVatIE/EL+gb9yUTgt+SzaNYHYJr1U4/c+Cp4bXAtzhgp1PiN46RGg22jhCe+3p1NHgTAE8dZO6tyZCzuIvNJ0E77epj7IMuWaammTBHf5PUDu/Dr2iWHN00GnedSqJy3uHXOcA9PoqvxLg+aazd4lw5gDgujptZu4kKlHa6ZkXJrk4pjl0bKoY5ROUjioXKrCohqFQucpnKF4QsNIHJXJXrlXAVB7FOxCsKIYEwQwhis8Hw34xcM2UNE7T0CqAUdhl+6k7MNZEEbSEGTdsezsri+S6//AJt+Uua5pExBkH8kTg+AvzZqnlLHA5YnNx3mIVng94KtNmmUSZB779VYVHEkkbBc2WryJbZdltc8Edy7PoQWgcVCysDlpyYHPipKjCQD7IS5omPK12nFc3K5t7l/6Pgo9MNuqIqOA4DiDwVHilmwatMkbq3tajmhxcNemqZc0pY3yySZPMe6rIlJbq57YWKThKr4Kzw7ezUyTrHl9Ark3+QlrxBPHmmuoCnBpgDSDoFDeua5sugQJJ/FRTklS7X8kltyTuuGBYnQBIc0wVOyiXSODR7lVda/YYa1zT2Mouxu2gOzOiYhI3rc7RqlCSgvgIrMLYSUa49Rtz13VhUphwbPJZzGaZognmYB5I5wlF+XoXiccnlfZohVBCzXiCmGkkCZ3CLw25JaCeSKxG3zsmNeBRKW5fKJBeFML8P0g2k2NJaCfbn0Rta5AOsaj9SFUWNZzKYbGo6qvr3ji/zCPufVMebYuEK8Bzm2y1pNlxPMp12+G6eyFtrgQkqVszlalHZS7Zbi93II+10JPug7e8yVA2RlH03ReJXgALeJComUXTqZS8ij0jRiVpuRuLS4BbvugfEFq0tzkGW7Ed+PTVCYRXI34DRXbhmbB4hSPKaM7XhzUkUvh+43HD8AtOBp0WVZZilVbDpDj7RqtcHeUdQiwdtP0B1lNqS9TznFLAse/Lq0E7bgduXVVbitxiNhml4JzA8N1m7yxzfwu57Nd3/dK7GDVcJTFbb6Kcv4KIuRNe1ewS5pAJiTzQrytlp9FIjc5RvISuUTlGGhqVI5vZchDCmFTMKGBUtMppnYQ1aXCfDL3NbUqQ1p2aZzEczyCj8E4SKtQ1XjyU4Pd+4Hpv7LbVauZ3RZdTm2Lau2BfIPQw9rAHbuiByA5AIp7Yb34KF9wCegUVW+BPZcuc4dhqM5B1aA0BLUIa2OKqamJa6+iEOJnNrqly1cE+PwHHSzZesgCTuo6dPMcx25c1V0b6SQU5t5DoS/qYPtBfTzVhVw0l0N9kDi1m8sLMzTmBB4QDpPX6IqhdQ6Oe6V7wXCdir/ANt8oKLnBoz9bAGMa0tbBEQ8HWRxP6hV1w1zXNJkgEGNgYW1rvmAB0jguvbFjmQ/zddo7QpLC27TNGPWONbl2B4VijKoAEyNwfz2RWJ2TKoyvaHDcTwUdC0psDfhsDcu559zxRT4idyjjGlTMs5LfcODH2Ycyq+m7RrYLTzB29lqMPqAhU+KYRUqw9sAN66kaSAPTii8Jqg6cAkxi45Lrs0ZpLJGwu4DBM8Vk/EjgwseHGCcp5RqZ+61N+6NdxxWcxsCpTcwN1IOX/NEj6o5Jb0i9PKuWLhtQO2OZW3wp+U8Fm/CtqacB75nWB8oncA8e+3dek4fb02hpDRrxOp9z+C6OL9Jb5k6Muo1sVLy8nnV3YXVWpnFMhgESY4ayYJ5puUs+eowepP4L0DHcYoNaWuqNzbQJcR3DZj1XlWM3zC4w7/a78QtT/TsEVTAjq80+lx+C4pYtQbvVb9fyV3aY5RedKrD0leT1jJOqls90H+n4H1f/YUp5PX+j124yvAMCeHAo2ldBzNOED23VF4ILiI1/D2Oi2F7ZUy0kjLpu3T/AG8UuX6S1zjl+z/yJ+qX2zRRU7gumNvuf1CFvqmSHECTpz1XPoEOkODmdOHKQocUdmIHDf3XPlCcG4TVNGzdF+aPRVYh/XDKTBB0PCTwKzVZpaS1wgjdaw0xEKvxuxz084HmaNeoG/5rbpMu3yPoGaT5M6XKJzlE56YXrpNAKRI6quQ7iuU2l7iwaVKxygaVK0qwD0Xw08MtaYGmYucepzEfYBTte8uLWjNxIBQxYWUqbOWVvs0E/WVFRrFudoMGJB49p/W68/qLeRykPxw44IsSvH0nSR5T7obCbmtXe45JpjSRvMc0DjV+5wyk7DTit5hdo2nQptbEZGkkaTIEn13SceJTTZozZFiguOWZu9tnAE7d91RWeL565oEQ6CZnlAP3WwxQ6ET+IXm+D2Dn3xqNOjCZ7RliOsq8WDG9yfov5DxzcoWb62tdQB7oTGraswCrTPmbu06hw4jurvC3NDSJEj3RbqOZsnYooYY9oyvO4y56PObfxWTUBPqBpurh2NtlpB32kj6Kl8T+FIq56bsgOsRpPGOSIp4ZTawAbxq46mf1wUyY8VeV/sbbhLmjUW+JhxAlWlesO4XnF0zKJDiR7aq8wCvWewmqYaPlJ1cQNyen1VRclHsTl08fuRsH1Rl0HomCjAzOPYKqp32YabAwrCpXGUDomRyqXZjlilHhEFTONGSeirXYgWS0jLJkjaTz6q/okZARxQ9xY06jf6wZvpHY7qpY75TLjkS7RT3d4HN3AVTfXOVjCY85I9BAjsTP+nqrO8wzKCabXObPP7E7qmxCga1u4MBFSg+S075HDU9QDJ91q0UV41y9iZv+PylPd49lqAM1d9B3j7LXW1c1GA1KjniRI+Wn2DBv6yVgPD9i101HanMYbPHqr/C6NZzH1GuGSkSDPU8htwXWlkkui4aSDXLNJiGV7S0NaR/lMDlyhYzEMMcyTpHTT7qSpitQjV8dtPqq+tXLuZ76rNPNu6R08Gi8PtjGYeXnQg9iCR3G/wBFM/BXAS17T7j7pj7ZoZnDzmHAbduaHN4+Scx6jh7KKVByxbnwaTwve3NF808r4MZHcTyBGxW6rY+yvTLRNOq0S6k7R3Ut/eHZeZYJipoVm1J0PzD/AKWg8VX1N7W1WGKnzNc3QgLViy8HI1ekqa479SzsLnza6gmD2K5xOdwmYc5vsSFUYPeh7fiukNb5nactIHUnYdVb0iT5iILiXEbwXHMR6ErPr9rin6mbAnGTixHNSUgZUpCUN2PULnxXJoswmOWfwqzmjb5m/wCU6j229FWPWs8c0QDSfGpDm/6SCP8AkVkiF1cUrimCMKVMcuTAdweHKamdQomhSNVFtHpuJDUf/Yfq1C3Vi52wI5FWNnVbUbTqETmY1w/zgfhP0RAqF2vAbn8FwcvEnEZGbSTRh8YwqpEupmOf5r0XDLgVaDHAQC0enCPuPRVdarOiKwek/LGjWCYAH60Q6ebUtiXBepk5wTl6AuIU3OJDeG8duSy+GeGnuqvrNqZfMRETOx11Eax7LfMAYT1Moa7eGmQicVG5N/DRWLUSS2xKTDrItqNz7zv0V9c3Q2GyArudUEMaTB1j8yjcNw9wbNXeZjkI2JUxJu4wXHuDlkn5pPn2KzEXtcMrlWVMPYAJeTI3EaFW2M24J0bMcP5IG6e17A1rQ2OGumkQEhrdJ8mvF9qoDpYTSFIu1qHNx5DgAEZbta6jmAAg7KCwa0UyyC10nQyZ13nkn2VACQQ4DcTt7K2kOfr+RrWtNFztj9VR2mLOaHSC8jVoB1jkOau6dHK86GDrzHdMNlTFb4ob5ogxtvvHPqqUoJU0F7/IBh/janVIpBrqb9odAAPKf5brVMuQGNBMlUN/4eoVXiqWQ8bnbNyzRv3UrcJAc2oC4ZQdMxynu3ZFLJBu4cfkzSxxaNE6PhieKo7rDHNIuKL4eOBEtcOLD0PPglp4iXnI4ZfXSFYXVdophoMoozX3LgRslDj3MpcYNbXRL6TxZ3H9+m7+yc7o7+7JVBiOB3dAnPTcQd3M87SOZLOHeFrsZw2KXxh/aAEj+Ib5T9YWbtcQFSCH5QJnX7cl0YanevMuvYdjlkh9rtfP+SptSw/MSOkfzR4/8cDRrnHuUbQY+s0+eTM5nBryAOAzg6IatZ1WkgGke9ID/i4I1OD6f8Dvq+fMn+zKy6eNYEDkquo/VaptCQM1GiTxIDxPpmKLsiymZ/8AFtyf4qeb7lNhBX2Sf6lFLiLM1aUX1AGUqbnu45WkmfTYLT2Xg6oGB15UFCmNQ0nNUI5NaNvqrj+nrjLDC2mOVNoZ9tVV1muLi55LnHckyU5whBWzBPXZMnlSr+S0w9lAgCmzJSYfJOpLv33dfdT1mQfLsqB1Nxd8xgQAB9VaWzFyMmSWTI2+i1FRiFgIgM29PuhgV1GsS6BsNf16ptUgL5Kf9oDoZR6uf7Q1Yd7lqv2gXE1adMf3GSe7z+QHusm9y6OFeRFWdmC5MIXIgiwClaoguaVZD0LwRefEouoz56ZzNHNp3HvPuETVrOohzZJbOYHjB3HWFhcHxJ1vVbUbw3HNvEfrovTLmmy4pCrTMtd5p/dJ5jkdjyK52s02/wAyJDJslT6YzBmCq3Nm3j2P2VtVqZdtuSBwlraNA7AyZ4aoG7vIO6wSmsUUl2XseWb9gm9vZPJJZWfxAXOJiYAHFVlxJAcTE8EdSxNjWtDTGkQkR5k3kHODUagaK0oNY0ACBv69eZUV3X03WY/p50wdtp3/AF3VbiniSo0hjKRqAzmcCPLppod/dbHqVNKMVQlaSd3JmvFQOM9FXMY3OdOKw1x4udSq0aZMNJHxXlsw2dQ0A6nr9Crm0xFtUvNGsH66wCCOUg/dKyRkoRk18miGLbJxTL+o0Z9gprpwAB0WVuLitTM/M7hP/W6A8P4XiOYvuLluUmckGofQyAztqFILcpO0vgKcNrjbNw57ch2Q9AsyuGmyGpW4IOYvcO/5KvpWlV1aM2WkJ2+Y8hqNCk7k2ui1BU+S6taojU8E3434oCthFWRlqkCekxxkcUuPYBUfSb8GsWPaZM6tf0dGo9EUIN0gZuCdplVidTkeP61VfhuKNpPcapcWxpHmg9lqmeF2uoeZ7jUg+YaNn/KeCq8A8HAsebgy8nQNdsOcjcyTvyTYYkuw/Hx7WPo4yLogUwco0JILYA3WDxezFC5qMY4loII6BwnL6bLb2Hh+5p1TS+IBQbJa8AFzgf7pHA9eijreCC+5c6pVPw3AEFoGYnYgjYRvPGU7DWOT54YM8kKVFB4cvC1xE/qVaX9bzArTO8L0KbWtDRpMOMZxOupG47rKYxQLKmTlseBHMKWpZBW5NWiS3fKPpO01aCqa3VxZvlbIrngyyH1HRsAFC4Im5I0QtR0lMyuoti49jrdkn6qwpNQ9CnHdFNbAWKEPUfKViVCibKmGNdUfoAC5xPAAT9tU21ty4zw+/Xss948xwD/4tM8jVIPqGfifRNhBzlRV0ZXFb81qtSof7ziew4D0AAQBMp2ZNldLpFDSCuTpXKrDoskiQuTJUI2PLloPB3ik2r8rzNF243yk8Y5cws08IZ5hSgWrVM9wxG1+LSLqDgWOE8wJ7cOqzFW3gZH5g796fseIWW8J+MKlo7K4l1KdWzq2dy3pzC9Oo17e7ph9MtM8OE/dp6Ln6jRqT3R7Cx55Y/K+jM3l05rRml0DUjfvChq3IIGUyICt73DHNmPt+p7j6KkusNa4hpJbJAkGNyubLFXZrhkTL7BbMZDUe2SflnaOcI6tYNLdQ0ZhoAApakDJSbyDVPoXwOAVqEXwZ3kldmTv/CtMgE085/i3HpKjwHDRQNWGAF8azPlEy0DgtfUbMlCvtc2nNC3kS2pjI5E/uKmtvKKbcNy6KevhMAwT67eio7x3wXta4k54DTGkkgR9R7rMoZIyNCcMi4Zb2122IT6VdrXbBUwpunT2Tq4qbgGQpGcqKlij7l465EiE51zPFYE+MKEfOZ5FpB+ylsfFtJ7subXfiO60OGdc7WL8KPubx2ItAiUFVxdrNjusy+u6qZp6gaaFMqW1RwPldz1QbsjfLHQ0uNdmkONty5juPqh7bxAHuP6hZ02NUsIDTPUR6pBQdb03VHtkabandNUZe/PoG8WCKZdXmMuNTiBt/NU9/dZn9p/L8FRt8RU3O4sP8Zy/7phSUrmXzMrVjwTTuSM+bLj2bYFwXDkprSqZhCMdx4JKd21ronX6+wWqDOdIPuriClw/zEn2QzbR1QgkFrfqfyV7Y4eY0ED2CLI77BicwAIu3sy86jTlz7/kj7fDw0Zne5/BZDxX45bSBo2pDnbGpu1v+Xg4/QdUEYSlwuhiYZ4w8TttGmlRINZw1jamOZ6xsF5cKpJJJJJ1JO5J3JKiq1C4lxcSSZJOpJ6niUrQt0IKCpEJ5S6FNaUqMiHykTJXKqDsswEjgnBdCqwqInISsi6iHeFAQbKjMMxWrbuzUnEcxuD3CHITCFOyUenYB4/pVQGV4Y7r8vo7h2K03w6VTWBzkfivBnNRuG+ILi2P9W85f3Xat9OXokZNOpdA1t6PZbi0qB4qNIdE6Ht90FSxg03P+KxzZ23PdZnB/wBotN2lZpYTuRqPcfiFrbTGaFZujmvB7Fc/JotrtcDI5uKkguxv2PaCDMz3B5EI+1IcZVIbCkTmZLCNZG3siqFVzBuHddtOyz7Z43b5RclGX2lxcEELM+LGsbS+I4SaThUHDVplFXV86NPodVQ44HV6TqcnzaTtpx+ytTUpdB4cTjzYXZXbXxUaZDh+p6o/5liMJsa9ufKS6md279yORWqtrwaSYngdD9UE4uD46Gumec+JcAFOu8B2hOYSdfNqeHOVSPw5zdQYI1W88Q2zqlZzhBGg57Dmqephrv3R7LoYs8tqtg7IMdgPiUUZa8fNE6xqOq2mB4uKzi3Ll0kayDz9f+1gf6IP7o9grCytHs+WR2KTlhBu49hN2uT0Z1MTEj3T3WQI19uCwlO2ruMgPJ56ladj717Q34cHi4wCfQpW1/kS+PUh8Q+GqNSmBkYCDoYA4bSOCzLvAtIQQS2f3SWx7brd0bOsWgVC0EcRJ9Y01U9PCQf7RxdHZo+kfdMxSzKVdICfh7eezFW3ha3buaj+he4j2lXthgYaPJSbTHUR9BqtAG0qQ/utHSPqVnsX/aDaUZDHfEcODPN/u+Ue62qM5Gfj0Ly1wprdXanm7QegQmN+JrW0HncC+NGCC70bwHUrzPGvH91XkMPwWH90y/8A1EaegHdZRzy4y4kk7kmSfXinRwe5KNX4j8Z17uWg/Dp/ugmSP4nce23dZguUYT8qckkH6DgFI1RjspGBWQmAXeia0pXqFipUyVyohapUsJyCx1ETmqF7ETqo3qWSgYtlMeFIWrizuoRAz2qB7JCOc1QvYrTKcSsqMUVOo9hlji08wSFYupId9FMUhEsYfY+NLulu8PH8Qg+4Whsv2mD/ABaZHUQ4fgVhqtBDupKPFCXaFvdE9ctvHdm/dwaevl/5Qranjlu/5XtPr+IPdeFfDTciTLRwfRazSPfxeUztlU9Ouzovn5lxVbtUeOznfmp2YvcDavU/1E/dB9Evcvxme/tNI7sYU8Mof+ti8Db4hux/jv8Ap+ScPEl3/wC9/wBPyU+j+SvFPfB8EbU6fsFILtg2DB2AXz67xBdH/Hqe8KKpiVd29aqf/wBu/NX9H8k8Q+hKmMMb81Ro9QFV3XjW0ZvXYTyBzH2bK8IMu1JJ7kn7p7WolpooltnrN7+0+g3+zZUee2Ue51+izmIftIuqmlNrKY5/O766fRY3IuhMjjiiUG32KV6xmrVe/oTp7DRCeiWmn5EfQSRzSpAJXNb2UmWENhpDQ1OhLCUBUWNLU9oS004KFUI0pZThHJMLdVZKFErk4egXKrJRaApy5cgY9ISUx65cqKGQkK5cqDSGSonBIuUKGwmOpcUq5ESiGpSQr6S5cjixc4ojdbqN1NcuRpiXFDHU0z4SVcisBxQnwkvwly5SytqOFNODFy5QlD6bUsJVyEOuB8pMq5cqLZI0KRlNcuVMNImYxOLEi5AHQoakcuXKwRWqQgLlysnoKnsaEi5UEuxHbrly5EkUf//Z',
                width: 300, // Image width
                height: 200, // Image height
                fit: BoxFit.cover, // Ensure the image does not stretch or distort
              ),
            ),
            SizedBox(height: 20), // Space between the image and text
            // Text describing the steps
            Text(
              'เฟรนฟราย (French Fries) หรือที่เราเรียกกันว่า "มันฝรั่งทอด" เป็นเมนูอาหารว่างยอดนิยมที่ทำได้ง่ายและอร่อย โดยการใช้มันฝรั่งสดที่หั่นเป็นแท่งแล้วนำไปทอดจนกรอบ เมนูนี้สามารถทานได้เป็นของว่างหรือเป็นเครื่องเคียง ',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          
            SizedBox(height: 20), // Space between text and buttons

            // Like and Dislike Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Like button
                IconButton(
                  icon: Icon(Icons.thumb_up, color: Colors.blue),
                  onPressed: () {
                    setState(() {
                      likeCount++;
                    });
                  },
                ),
                Text(
                  '$likeCount Likes',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 20), // Space between buttons

                // Dislike button
                IconButton(
                  icon: Icon(Icons.thumb_down, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      dislikeCount++;
                    });
                  },
                ),
                Text(
                  '$dislikeCount Dislikes',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 50), // Space between buttons and the next content

            // Center the "Open Page 1" button
            Center(
              child: ElevatedButton(
                child: Text('เปิดหน้าที่ 1'),
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
              ),
            ),
             Center(
              child: ElevatedButton(
                onPressed: _launchYoutube,
                child: Text('ดูวิดีโอ'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Method for creating step text
  Widget _buildStep(int stepNumber, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Text(
            '$stepNumber.',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
