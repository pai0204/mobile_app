import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart'; 

class Page6 extends StatefulWidget {
  Page6({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page6State createState() => _Page6State();
}

class _Page6State extends State<Page6> {
  int likeCount = 0;  // To keep track of the number of likes
  int dislikeCount = 0;  // To keep track of the number of dislikes

    final youtubeUrl = "https://youtu.be/5_ApsIOYZeA?si=aLsdt1EmckvWuF77";
  Future<void> _launchYoutube() async {
    final Uri url = Uri.parse(youtubeUrl);
    if (!await launchUrl(url)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor:Colors.green[100],
      appBar: AppBar(backgroundColor:Colors.blue[100],
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // Add padding around the content
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center the image
            Center(
              child: Image.network(
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExIVFRUVFxcYFxgXFRUXGhcVFxcXFhkVGB0aHSggHR4mGxcYIjEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGy8lHyYtLS0tLS0tLS8tLS0tLS0tLS0tLS0tLS01LS0tLS0vLS0uLS0tLS0tLS0tLS0tLS0tLf/AABEIAMIBAwMBIgACEQEDEQH/xAAcAAAABwEBAAAAAAAAAAAAAAAAAgMEBQYHAQj/xABFEAACAQIEAwUFBQYDBwQDAAABAgMAEQQSITEFQVEGEyJhcQcygZGhI0JSscEUYnKC0fAzkuEVJENjstLxU3ODoggWwv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAAEEBQb/xAAyEQACAgEDAgIIBgIDAAAAAAAAAQIRAxIhMQRBUfATIjJhcYGRwTNCobHR4RQjBXLx/9oADAMBAAIRAxEAPwDKGsNTV67B+zDEcQCzzMYMMdVNrySDrGDoF/fPlYEa0T2SdjhxDFGSdb4eCxcHaRzqsXmNCW8gB96vQmI4pBE4ieWONit1VmVbre3hvvtypOOHdiceO92V/g/s24ZhwAMJHIebTDviT18dwP5QBUvN2ZwTjK2DwzL0MERH/TR8Z2iwkQvJiYV8u8Uk+gBufhUBL7TuHA2Ejt5iJ7fUA/Sm2kPUG+EQvaH2W8MxTyR4cnD4hAC3dEsi5vdDoTlF98qlSd6xntX2TxHD5e6xC2BvkkXVJAOanqOanUehBOu9ke28MEmKQrLMJcRJNG8SFmcPaylTZgQAPqOQvb8Vwb/aOBaLGx5DKWZV0zweI90b/jVbX9WB0vQNKS2KyYqPLKJejE8h86f8a4VJh55cPILNExVv3uYYeRBDDyIpukdZ265MbE0hpewFdNJsaXdgXZxjXI150FW9HU6VbIHFc3rm9GXShKDBbUL0UmhVEO3rt6AFGC1GQCijBaFqFr0JYL12uXrl7VRAwHWurRFNGBqFC0MTOwVFLMTYBQSSegAqfk7E49VzfsrEdA0bH/KGJ+lX72W9lljiXFSC8soul/uRna3mw1J6EDrfQ1irVj6ZONyHRxWrZ5y7N8Q/ZcXFK11CSWkBuCEN0cEb3Ck6eVejINqqnbbsLFjVLraOcDRwNG/dkHMee4+hL2A4lL3ZwmJUpiMKApB17yHaOVT94aZSR0F7XtTcUHjbXYZjTjsy50m5roaq17QeKnDYCeQGzFci9Q0hCAj0zX+FN1oY9kYz2543+14ySQG6L9nH5ohPi+JJb4iq+WqT4B2cxOMP2MfgBsZG8KA9L8z5KCfKr/wr2TLvPM7HpGBGvpdgSfktY1jnN2Z1Fvcyy9crcV9mOCt/g3/+Wb9HFco/8aXiX6Jkx7HuFiDhcGgzTZpnPUufD8owg+FLe0jss2NgVogDNDcoDYZ1NsyXPPQEX5i2l7099ncobhmDIN7QRqfVVCn6g0pxHihWcEMRFCsxmF9ysccugy+KyuLajc71o2o1QbVNGacH4dw+JoFeGafEvKkb4eX7IxXveQJl+0Uetram1aF2v4snDcJ3kMEdywRFChUBIJuwXkAp0HlUtieMxpEZjmKiQxWAuxk73uAoHnJoPWmWWPHQtBiI7hlV9LgFSSVZD7wYWF721vuKiVcDHK3bITtxw5IsL+3L3ceLg7txLEMgdiyqyEX8StcgAknXfe93Q3ANrabdPKs84RwnBK0RM2MxCRuvdxyvmijYKrBsosLLnC+RuLaVesFxBJSQl9ACfizrb5o1RAy4Ma9vPDAuKgnGnfRsresRFj62kA/lFZnsK13/APICcD9jXn9s3w+yH6/SseJrJlXrs5+X22cZqIdaOegpVIrf3vQXQAkFoKtOAlcyUOoqwmWuWpQpyoxW3rVai7EglGtR1HM1wiqsuzlq7e1cJtQFQh2uXopauZqlEDk0UCuA0L1dFBgal+y/CDisTHByY3cjlGurH5aDzIqIUVoXsZhBnxDndURR5B2Yn/oFHjjqkkFBXKjYsJEFUACwAAA6AaAU7FNe+Ci5IA6k2oR41CLqwYdVOb8q6JsHLCo7HYMFlkGjpfK3kd1PVTzHkDuAQ5/ah5/5TSE+IHQ/5TWDrepeGDklYcY6nQUYix8j9D0qF7W8CGO7iJ2IiWTvJADYvlUqsd+Qu1yei6WJBDvEyZRc6inmFU6MRpavMdJ/yfUyzSUItp9vDf8AY1ZMEdO7HGAwEcSqqKqhRZQAAFHRQNhToiiq1HvXtMbdbmMJahXa7RkM49gPaESYaTBsfHAxdB1ikOY29JC1/wCNaufEcNiDLKyYeBlYFAzIhdozCBZrsMwMpHhNvDGw5qa82cA4rLhJ0nhOV4zcfhIO6MOakaH5761vnZbiWD4mJJY5ZI5nymaHMmZLBRoCuqEqDm5+WoCITT2BxTXBKMZwgjhggJXve9RcmVJhleAWJG9wSbXtY6UJGxyg91h4QQoVfd1GWS40cWAcxkDmA98twQ9l7NxN7zSE/aa5hvKArG1rXsNNNLnqaWXgiBs2d/8ADijIuLERNmU7b3Jv1vTKG2iOx2En7wiPDQlFN4yypcFY48h30s+YdQo01Au57ORlTKrRQxsMmkQUG1iFz5TvYbfKj/8A67FaxaQ+HLclbgXJuLLvYlb9PU3zjt320hwqSYTASZppAqTTAraMIuTKpUC8lhbT3fIgADJqO7BlNJblP9q/Hhi+IPkN44B3KkbEqSXYfzki/MKKpxHIUdEJsqj/AEp7DhgvmetYJ5N7Zgk7djeOG3rSyx3pwsPWj5dKQ8gI0ychXBH03p2IulArbaq1lDXJai260u5A1NqanEBmCoC7EgBVFySdAB1o4qUuAoxb4A9Edgu5FzWndkvZkXUSY0lb7Qo1iB/zG3v5La3U8tC4V2awuH/wcPGh/Flux9WN2PxNa4dM/wA2w2OF9zztHwzEt7mFxD+kMlvnlpnj4J49JIpI/IxuD9RXqdoab4jAo4sygjoRetCwwQ6MIx7HlGPEody489D8xoR8z6U4hmvod+R61uPaj2a4XEKSiCKTk6C2vmNiPKsO41wqbBzGCdbEagjZl5OvlUnjTQbSmqYrm5UcGm0cl/7+tHD1klBoySg4umL56muzfHMTEGgwUf2+IZRnFmay3sFBGUWuxJPqdqr+atR9i/B7tJij/wC0n0Z2/wCkfOixR9bYvGvWLF2Y7Am4n4jK2LnNjldmaKM+SnRj5kW6DnV/UW0oi10tW6qNQfPVa7Zdpv2URJHH32IxD5IYs2W9tWdjY2VRa58xtqRPs1tTpWd9hpv9oY7FcQY3RG/ZsMOSxqAzMPNsyn+YilZMUZcl2XDBYKZkBmcFj7wQZUHkL3JHmTr5bVKxRBQFGwFqUVa7as/T9Bhw5Hkit2FLJKSpjd9NRR4sQCLj+zR5BWf+0bh08cZxmDleKWLxSBDpLGNyynwsygXuQfCCOlbgGy/Z6FYLF7XMcAAUw7eZRwT5m0gHyFdpfpUVqRRnntou/XpQwsrxuJEdkdTdXVirA9VI1FGEQXf5U6w+H+83y6Vjc1Hgz3ReuA+1biMYAlMU6jnImV7fxIQPmpNTE/tnxFrLhIg3UyOR8rD86zB5KAa4sPif0ofTT8SvSS8Sx9oe3+PxgKPN3cZ95IR3anyJuWI8i1qq+XZVBPIAC5J6ADc+VKhCSFUEk7AAkn0tvTzh8RSYxqB3rAKplRfsptwNcw1GmYjpsASRcm+RmHDLNL3Ehw/s3iMlwQGNiUKqCnkx8TX/AJLb1GqZ++eIZGye8fCQF2z3GXQEi431q6zzYiOGR5IYXRUUhFc728dyVZT5WtpeobA8fweHGQKxGXOrWRypY37lQpuoF2NmYW161mjOcrelM6voMaVURk+MjjH2ga52KDMCfibf/Y04w6JIAyOrA7Xup08mtf4XqP4zjXxkgSKJ7HUJbM5/eCopfn+9UnhPZ7xKbeDIOXeusa/5Eu3zArTDpHOKbVMx5cOK9iNxXEY10BzHouv12qPxHEXHSP8Ai1b5b/SrZN7KOIhdJcOOqozr8M2S5+JqvcQ7E4jDKTNBIbHdbFLW3LJcj+bLWiHSQhzuJjjxogZsXc/ecn8RsL+g/qK2v2Q9lVSJcXIAZJL93oLKm2Yebdfw26m+Iwr9ugZbAumg2ylht19a9V9mIVXDxqnuqiqvoAAPoK0RSsOXgSqpQK0rauWoyCdqKRSpWkzUIIutVD2gdkI8fAV0WVLmJ+jfhP7p5/A8qubUhIKhDyTNFJDI0UqlHRiGB3BH6UuGvWqe2XswHj/a41+0jFpLfej6nzX8iegrIMPLbT5UucLI0pKmPq2v2R4xP2JVBGZXcP1uWLC/8pWsTB5/MdKk+Bcdmwj54iNbZlOzW/I76+dJi9EtxC9SW56aSSlL1nXZTt/FiPA10lAuVPPzU8xVo4n2ghw8LTTPlRfmx5Ko5k9K1KSY+yC9rnaT9mwZiRrTYm6LY6iP/iP/AJTl9XHSmvsJkBwMg5riHB+KRsD9fpWSdqePSY7ENPJoD4US9wkY2UfmTzJNXb2IcX7uebDMf8UB0/jS4YepUg/yGla05gqW5uINC9IrJQaSnBHZGpliGHP60pNNUTjMaouWIVVBZidgqi5J9ADUIecu0+DXDYueBfdjkYL/AAXuo/ykUKHHMX+0Yiaci3eSMwHRSTlHwFh8KFZpSjbFWPIcPbVtWP08hXHNKTPTUeL069f9KwK3uzNyFsToNqVjQkhFBJOgAFyT0A50dEJORFLHy12pLicbRZQdGYK+xV0JB8B6Hn56UyK1OhuLC8nwJzgXEMPh7973kchU3ZlBy8sqqAzXPUheeu14/D8deMtIBd2zKJZWyhoybi6czp906Cw9a7LiyvhQBbfet4j6E+78LU2UM7WF2ZjbmSSdh51oj0sN2+50fS6VpjsiV4lxkykGR2lI2HuqB0Ba7H4j41b+wPs/xOOtLIThsNuGUWkl/wDbLXIH7x06A8rX7O/ZPGgWfHKJHOqxHVE/jH3z5HT13rXkjAFgK1RgooS5uRFcE4Bh8IndwRLGvOw1Y9Xbdj5k1IFBS5FEYVdgjZkpGSEU7IpNhUIZ/wBsPZ/BiAXRRHL7110DMOo6/vDXrcaUj2B7V9ywwOM+zlU5Y2bQOOSk/i6dfXStBdaoHtK7NLPCZFFpEF7jmBrb9aCS/NEBquDTlN67asG7C+0yeACHEXlVdNT41tpa53+PzrXuEdqcNiAMkgDH7raN8jv8KpZYt09mXZNGistcEooNIOtNoITcU3kNHmnHWoiXi0ZJVCXINiEUuQehyg2+NUQbcfCmNg21jf0rzJxOBUlYJfISSl/wEm3ysR8K9LcY4ZiJ4nRAqFgQC5tv/CCazjiHsfxbhf8AeIPACALPzN98tU7siMxwsvLny8/I06Guo/8AFWHHezDiMNz3Syj/AJTg/Rgp+lV6aKSNskiMjj7rqVJHoaXOFlyipoWgmZGDoxVl1DKSCD5EUpjsRJM2eaV5CNs7FreQvt8KboQdqUrK21sZHcdjiRCl8JiHhkSWI5XRgynzH5jkRzBpEGj3obYNuzdeyfbiDFqAWEc1vFGxsb9Uv7w9NRzqxTYmwJvoN78q81Gx3F6MDytTl1LS3Q1ZvcbvxDtDh0vnxESW3zSKPha9yfIVl/bbtn+0AwYYt3J99yCplO+UA6hBpvYk9ANaw40AtSbDSqfUOSqiPLY2yUKcWoUvUBYu93PRfz/0peDDvIwjjUsx5DoOfQCuAXYKN2IUepNgPnVr7LzLEmVoZVY94ZZAhI8B93wq73AtyQb78885NRtIbg6d5n7iLx2BGHMarHJ36Hvc5yWYLuqBSx031sbKdKL2m4RIytiS+dXINiSXRWHhD32t7tt9RUvgVjefvXlMgZr4dTLIZgVBDeHxMFtf4C5pXj+KRY3+xEpUEHM92X6vl0POx2oI5ZRkl38+J2PRRUdK4MuxUXzFXb2LcIWbHF3FxCuYfxMbA/Q1W+I4Uqetwpv1VgCp+RFWP2V8YXCYu7GySjI3kQbqfqfnXWjJbGHJHZnpGJbClKSw8gIBHOlqcxSOUVhRqIxqiCbCkmpVzTSeYDcgVKIBzUdxGxUg9Kj+L9q8LAPtJkHkDmPyW5rNu1PtEacNHh1KIdC599h0AGijz39KCWSMQJSRnXETkxEuX3e8ci3QsSPoasXB+LXA1qq4x/tWvzt+QpTCT5Tr/wCazZsKnHfkko2rNVwHbOeEWz516Nr9d6kJvaiLACE5yQPeAW5033+lZeccCOdF4aglmRdSL5m9F1+psPjScXpILnYGOpGgce4riMTZRKEjbwvlvz5+Y9f/ABq3Z7h8cEEcUShUVQAPzJ6k7k8zWTdkMKZJVjbdTdxvcDn87aVs+FWygVvx77jKFrUQrStFNGWItHUdxTg0OIXJNEki9GUG3mOh8xUsaKRUIY12q9lTJeXAsTzMLnf+Bj+TfOs5kiZWKMpVlNmVgQynmCDsa9TOtVLtr2OixilhZJ1FlktuBsj9V+ovpzBXkxKStcgzjqRgptQVudLcRwUkMjRSKVdDYg/n5g736U1dqxaezMrQoGpSKm4pxHQyBDPSLjWlidKROpqoloMKFEahV0WW3s5wgSjO8TNA1rkSKCk0bEDVsoAIJuBm3A15WXjs86QtIHhQgHwvmYNyFsxjS/kEbkBUdgeIYi57nDq6OitGEvFrp75XOcxuNGddFJOptXOKNDJMFeN8PJGBIzmNcxCG+0ZZm3vqwsL+dY5XKe/H1/Q9DGKiqSGHC+zqPZ5Se5bLJEcyDNmAzIwNr3sAco5U24y6wBI4S+WHxmJu8y5C9ySHVQ12bz3FquXDZ0cWgMa5lzBVABUXPjZI7uASfvOPgarSYN5sQ7SKpMTWICPkkQja4zMWuNbnTw+lXHI3JuXC7BETisNJLGWaPQElXACh4mFxlA0+WpvVWxMZU6HUag/UGtI42BFGWD92g0ARVAUWsALB2HLmPSqVxDCmxupDLfcbgan10IOnU1t6XJe3bsZ80O5pnsw7e+BY5jdRpfmh/wC38vStQx3HsPCAZZ40zC4uwuR1AGpFeUMBjWw8oce6dxV04jxlpYYgCGVM2UndQ1rr6aD5VplkljX7HNlcHRrOO9pODT3DJJ/ChH/Xlqu4z2qNr3WHA83e/wAwB+tZZPj28vlTR8STuTSfS5pd6A1SZe+Ie0TGv/xVjH7igfVrmq3juOySf4kzv/EzEfIm1RODgkmcRxIZHbQKNSf0HqdK0Xg3shmcBsTOIwfuRDM3xdtAfgaiwznyyU3yZvicQN/zpsZq3zBeyXhyWzxySkc3lfX1CFR9KlE7A8OXbBQfFA350+OCg1E8w4q7PcDpTnuyALg+Vx+VekZuwXDzthIlPVFyH4FbGq9xf2WwMCYZJIz0ZjIh9Q358qa4jFKjCZcRlNgAT57CrJ2NjNnkY6scq8tBqbfH8qZdruys+Df7RPDewcaqfj19aX4FPliW3K9/iSf1rN1P4dIDK/V2NI7H41I57NYGSyhv3uSn15eenMVq0D6VgmGxAdSD/f8AfWtB7H9qrhYpzrsrn73QHz/P13X0vUUtExUJ9maCDXaQjkvSwNdAeCimjVw1RAhFIyClWNIyNVkM29rPARJD+0IPtIh4rbtHzHw3Hx61jl69F9p50WCQv7oRr+lq82YWYH06dKTlhe6AlDVwPYlvTgUnFjItmJH8pNP4oVf3HVj0uL/KsM1JcoTLFLwGjUnbnTuTDkbi1NpBQxdixGhR8lCmWWbB+zNGgRWWGFVsLgtk53DTMo/+p9aquCRsROzNMjmFxmd2WNWw7DZQoynY+RD61K8UxmZVinhySTXW+RQFuD4S7d47NpuFBYkWtXeD4rDxoEEqmSEhMzR91IxOyKHDSGwsoCquwA51z46lFvl+e56MT4pFg4YGIgZgVIzJG5Gp/G+VbX12NQnAhimKpE4IgJBVyGjyvm8WXQNzI1O3Ted7Q4eVpY4iLpITntGzSKtrAnMXcLmy3sq7WFPkwyxIsck5UKvIKryKBvbxysR5AcqinUPFvx3LK5x6SWNIkxQVklbLJIrMfDcHRbIiW06+7eo7FY2No8mWQmNgi28YUDRGJHh1A5C5HWlcVhI5527pZXja0TO4lcxtcMWu2Zzpa4sN/lOSQYhVK2DFQtycsXeLb3my95I3W/guem1NUlFLx58AWjNuKYOxtawOw6HmvwP6U1wOLKXUk2qckPehw1gwa1rnQ7KbsxJvqpJ8qgMTDr0I3rqxeqO5gy4+w5mxJPu1zDYZ5Gtc+dt+lh503jZF95j6AXP9B8/hVm7EsjSKzLZe9RN7nMQbFjtubaAb1TjpWxmcdKNZ9mPZlcPHnKjO9rnoOS3/ALvWhqtR3CIrIPSpQVpSpUSKC2rhFHrhqghMrSbJS5FEIqEIfjHCo542jkQOrCxBFYN2v7KycNlzLdsM5sp5ofwN+h5+u/ouQVB9oeHJPE8cihlYEEGhlFSVMpo8/YbF5GHQ1YcLib+f61XeLcLbCzNAxuuvdt1HQ+dKcOxRU2PKuZlxGeUTUuzva1o7JLdk5Nuy8rH8Q+vrWhYDHJKoZGDA8wb1gyTEDMuttwNz5jz/AD+VK4TjjxnvIZGW/NTofUHQ/EVeHqpw2luv1Ljka5PQF6I7Vj0PtUxCrZoo3P4rsvzGo+VqjuIe1DFtfL3UY8lLH5k2+lb11EHwO1Gzz4kDnVd4t2sw0WjSrm/CDmb5DWsK4r2txEt8+Ile+4zZR8lsKr4xjZg21qJTb7Fq2aR247VnEAoLrEOXN/XoPKsxgJFiAbbbaelTU84NixzXGwP5nr5UmczADRVHID6nzqIYlQWFQSAeel72tfqbbUXinDHicBrAna2n097pr50tHgmY2UE+gubXterBiIIjiBcCIMuZxIhVXUHl95nvrfy+BzZJ6ZqvAfGGpELBiZUssl26q5uw9LXPzp1EUlv3Z1G6nRh525jzFWiLD4d1UoYx3gOXqxuR4Ywc589QRbUVX24A5xOUEKRdlIX7uwuqElTfmSPyrIssZt6tn58+JMnSqQyMBrtT54biF0JQkc2yA/G1Cg9IvFGb/CmSfGcJNLM8JmEjhVaDIqoAwIzrZASrAEEEnQLc1IpFhASWw4M3hEgDNMwa24WIvbXW7FTzNqU4Pw+LKUIhlYAuLASBEa11axEY8WbUsb32IFPsXjnEDPB3bgBiLZnXQWYWhVUBFuZO1qTN1UV/B1rKhhHZpnGFdo1xIZVy2jOZASoNi7AWzAWI1YHap7BLiokOYxtlS3doG0f8T90Czki/vEC5vROy/CcyFy0ZWWzZDF3hjkAs5yg5UuQNW5KOppDtaw7tYxiGeS+kZa4dVuxDpEojAsPWwtvVyeqWgsb8K49DGUbu3RsQbTMGJGZcwAWONs1ixIFyDY31pTiePixECpFKys5yKiuRITfKM0cW17GxcnTWpHgnD4VGfSVZiJFiETP3bkC40uFNrCzHSw87xfa/EmWRYO4MbIDIhYqS1tcoSNSuwubnZataZZKS8/MobQcEQJqCHyhJsjeEMBoCqadPe63qrccwJRjcag5W9eTfEfUHrVpwnBjLGziV0SUZjGmYZX5khTkAsNmvpao3jEqs5UyCRrG4HdgqmmlkFhY6i99R5itPT5Gsjjd/YVljasocsdjVo7GnNHLFezE5kPRlAsfnaojG4exIPL6jcEfDWjcKxXdSKw5G/wDUfKtuVOUGjn5Y+qenOx/EhPho5OZXxDow0YfAg1YRWV+z7i6xyGMnwTfaR9MxtnHx0b+Y1qETXpuLIpwTFQdoUJrl6Ei1xBRjDtFYUpaisKhQg4qPxy3BqQemWJ2qyGX9q8KuISSKwzLrf8LDUG/971l0b5hf7y7+daX21xHdyOORs3O3Q3+lZRFiPEXGxJuPU1myQsqassfDMbUZJjLzSFdFvy2JG5+JvXJZ1QZ81iQcoG5a2mnS9rmo3Dmy2pGPEt34i1DYeYrHHlUbI5bc3pymHLGl48Oo8z5f1/pWmEFHgdGFDCPDE08hwIG9LSTKuh3/AAjU/Hp8TTXEYs2IBy/U/wCn0o7GJD5Ixt/f9+tFxMwVdLhrjKbAg+RvoNKZ4GORz4Lk7Eb2P4rVfuxvs8mxgDTFY4PvPYl2IO0VxYHztp50pyblpQaSSsZ9lMPI4CxRzSF/uAABb7EyEZrea9bmrVJ7OMfOwLvBCBdlsWZ1b7tzY3A8ivpWn8G4ZDhoxFAgRQAOZY25sTqakYlqQ6VatUuQXnfCMrg9lbRqCSkjAg2BZBcC11JBb4XtVN4upws00KiWIMF7xTdLMTYSpYlnXrbQ/K3ow1SvaXwFcThGcWWWHxI5Nsq7OpP4St/iBUn0sXbTf2Ch1DumZdHDiio+2S1hYgwWK28J8UJOosdTz5bUKkocHoNMP8MI5HzL3PrzrtchyXu+hurzZJYbs4JIwcUGzBCrAlcuhKhwzajw5fSojj2JijeLup3nihK94hZpUVB4Vtp3dwL2BJ1UE7GrhjcNH75wzTEXGZwGIA1JDTMNNPug1WMBCcRLLL3N4ZVCyRoy3RozYB7lFQ6EnewI66VFttyb2LTQ5TF8QDyoIu9GYMjSAeFCL5FyfZAgczzPPam/EcbHNP8AbpLEYFEi+7I7WIJBEYMagW13BvvVgVJSuWMoFVQEtnxByqLCzOVjU2Hn61TcLFPPOxa8sschzAW8UOxHhAQDQ2udSR0qoVJ3SVfX+Cy24biwmKiORM7rmyj7V1XQ3YJZIyLr719Taq/FhnlxR7yV5FRgUkVUkVXQ3MTLH4BmDAkm22u4p5i8Pg44rNGigA75sQ6HViGEXhU36vvbyqB4aZ3vh4HYAWmRMwCshIYqVA8QuwJBNrctauEVu47fH+Siz8Vw8TI7TCSQ2sUb7XKbqbtFD9mNAdST61RMJhQ7lkV1hcfdBYqUJynLHcAmxsGsB8r23HzYtMPM0iwzHSwuxRBYeHukGXQ5jctfbeo2HiGHTJEiyZZQXubuGkOUZFijLWJAvrawGutFjcop1v8ADglFb45grGwB8NyL2vl+8NL7HX0PlaqxMuVvI1fcbjIpIw/eqDc5FJUNocv+GoJAJH3jsaqvFcHY6CwOo8iN1+B/TrXT6fI5R9bkx5oJPYsHZTHlo8g9+E94nUjmo+o+K9K3XsrxYTQq4N7gXrzJ2fx5hmRjsDZv4Tof6/CtQ4LxlsHNbeKUkp0vuyetzceRtyoFL0OXfhnPfqyNnaXSjxnSoLhfG45hdGB6i+o9RyqXWUVvVPdDUx1eiuabyYkAXJFVLtD7RMFh7gzCRx9yKzm/QkeEfEio9uSWWmeQCqp2o7WYfCL9o/iI0RdXb0HIeZsKy/tJ7WMRLdYAIF6g5pD8SLL8AfWqDLiJJGLEkk6liSST1JOpoHLwK3fBPdqu1D4ty7AIovlQa282PM/Sqvhb30GlSUPDDbM5Cr1Y2H+tLRlBpEhcjmRZR526eZtQpUHGNDVcAWOY7dToB8aXRFGijOfLb+pok2IBPiYyEfdTRR8dvl865nd/CLKvRf1P9ajaQxK+A0+IC+81yPurbT1O35mkGxma4HhHrb67mkocKTJlzAm+5IsRbUX2qy4bABVJEeYAa5bAHS9szaH1W9Ky5lEOGNsgeH8OJ1PunY3tf9T6VKYnAZIz4L6aj3dOoG5tvvTfhmEDsNe6FyVfX7Nr6ozaaWtr1I6mrxwDse87d1HNIqFs0sgUe6bXAZhmuRoLE73O1JnJuaV/IaopRsHsu7FftH20qjuB98HWS2gS1tNRqb3FgN9tuihAAVVCqosANAAOQpDB4ZIkWONQqILKB+fmfOnsJ0rbjxqO/cxznq+ApHHYVy+tcZ6LemgBmaoLtpjBFgcQ5JH2ZAta928ItfS+vPSpkmsZ9q/bVJXGFhOZYmu5BGVnFwU094DYjQUMnsFBWyvQcXnVQGiWQ752ZrkN4hfK1hoQLDa1qFRGH42VUKEaw/5rjU6nQedCuW8Lv2fP1N/pF4mjca7+CMl5jKmbMziEs+VmJOV5GMW2igL08zSUXGYInaMRFQAX8H+8MzaEkWPdqwtq2uotXOOYKOSUMshlVs0MmZnkWN30DqzEhSuh02Dchapbh69yqRhDNIkYGaOA3IAsLSSERjTlc9axy2juvsOGGPeLEJGjPmlmHgQs8rHMtxopWONgNSLcrU44Lw2KGMJ4JJUAVu6Ga4BOQHZVNgPeO4JqudoMXJiGcmFY2woVirP3jEk6iyjJlHOx1uN709wfZ2PEAyCZrSoM8calRnNrhgt0FtRYjQGhcfU3dL6/t2C4HXaXirrEVWOMxkWJL52XkbpGAugB+/e9qT4NwgRrlYQyPqUJvMyxtqFaJANNTqW522pPi+IaDFKJXLIUOVHJyI1rC8MHvg6qFI3PlXcBx+fIV/ZSXDhXYeGNFYnaNR3jADcE6335VFFqFR8/Uqwva0MojLTMwVlLQs6JdV8RskZGmhOpP0ouB4ekKL3piszd5CCC8oDWNhGgud73vz+FCaHDSYnvM6xCG3eZ41hWUPfwKtw5uA1yb8t6sOFeKNQYo0jWXxrosOe4F2AsZGJFtwNB6VHJqCX9EsofaSYOwiETqJGsGkHd9NQtid+RsdKiI4jJGVcjOGKHa6yLsSL3sw0J0F/SrBxaF552jmcRqVvESpiUWNyfGM5bQAC/I+VK4zB3Q52yqAfCiLFGbcyZCW00OhrThyLEkv5AnHUjOMXEVN7eRqyHjitgCjauhULrqDcZX+Av62IprxeDN47hr6MRqCeTj+IfUHrUFIMoKkb7et9DXQnBTqznZIW7LPheMkoCWswG4JB+e9I4ntTiRoMVP8J5f+6q4khtalYsMzHaghgUXsKWIWxnFppdHlkcfvuzfmTTZIGapMYBI9ZWC/u7sfhy+NqUXFNa8KCNP/Ucj8zoPRRetCiNUUhCPhQQZpWCDz3PoNzS0c417iPbeR7WHz8I+N6ZmaMEtcytzZyQt/Ie83xt6UHd3tmbTkPdUfwqP0qnJINRsLiMUt7sxmb1IQfqfhai/aPoSLclA8I+A3PrXeHYEu5Byi1rg3GvKw3PpVjHCQqEu2VOpIiX4X8R9DekZc6i6GQx3uVlYyM11u68vLrYdOdTGAeNveVgtr3KswPKwVLj4mu8EwY7wfaqgXN9o5KJIl8u5INySR6elW2DNb7GF5rDXL/u8XPUMbufS+uh50jNlS2/r+h0IFe4HBCl5TIgjY2RHF3vexIVTYa9dLWvVmmi1yKw70C+gE0gH8K2ji16nWq9w/Cd5v4YpHIkVLgRSLfJcHMSLHlyJ2tV24J2OjcEQ94gYWZ1MsS26bgt1tbX40nJHVLa2/hfnyxi9Vblc7J8GnkmZVbu5rkNmjD3BN2YaZUta17kbDpWz8E4UuGiEalmOpZ3N2djuSfyA0A0FJdneBxYOFYYh7oALEDM1uZsKks1dLDh0vU+TDly6tlwHFHBpJbmo7jHaDC4Vc2Injj8iwzH0G5rSIJbNTbiPEIoEMk0ixoNyxArKu0XtnUXTBQlj/6kug9Qu5+NqzDjPGcTi3z4iVpDyBPhX+FRoPXehckglEvnbz2qviA0GCvHEdGl1DuOYXmo89/Ss3jWjRw0v3dLlKxsY0EyihSmQV2hDNl4UVSdssilsQufKoLWy3uVkbKm2p0+75Uv+1lg3dlXdTlJAlxAueoQKitb5Xphwvg6zwxmbvS8JsAwJVkU+EWKkBStvXXmK72ghhhQpFO4a5IiEsjXJN2uqE2662G9cWcVKXvNi2IrgmFnlkeV2VJVJUl4maN1NreBCoIBF9WOp15VYsakfi/aJpLWtkMndpb+CLUj1vUD/t7EO0EkUIeJlyiNUyrdbIzXS7WDbDQG2w3p3ieNywxfa4YoXuT7kcQubWGTPIeRJI/pQTjJtV8qqwyvYbBQvM3dFkhkOZHVGLI8Z0IABbqADa/h8qu02Km1yQi/IyssKt1ZQuaQ+htUZwrFYeAmKOQ3ku5LXgjFtPCzjPrytobUri5neMyQSkKCQWijREa1wSzym7AHmh3FVkuTS7e8jK1naSdmkCoO87qXIp0jYAjNmzaXW5IANgdan8BwKOFc0LTFspHe/wCF4SQ2Vi4vbQagWsKL2Y4XJlEpZlm8SMSgdnQWbNmkuNeuu1q5xyHBpGzYiSSdxmIJZ5bMRawt4EPldedMlJXpi/p5+5T5K5heKToksaOrSBi+cI0zyLfVjLqoAtl1HMW6UsszyMGOGeNCl8wBlkzaWXM1rCxJOh2tvTvgOGAcB37qaAMirl7x5IxrqgXZbgA3OoHld5x3HTJHmWEgW/40ihjba0UenLqD1q8jWqkt/p/6RFSRhKGvc2zAqWvIV3JIAsttCNfyqLbhzE2XK45EEbeYOo9DUhglbPFIGISX38uaNFkU8wubQe75+lL4/s3FI5dWIBNzpYD4EX/SuhjzwgtMjNPG3uiCeGJPfcE/hjsx+JHhHzv5Ub9ofLdAsEf4ydT6Nuf5RRJQsbERoGKm5bRyUBsWXQKNfK/nRJEzBncP6lWckEb3934GnvKlwKWNvkbd/GpsgDt+OT3fULz+JPpRznkNzdyB8B6X0A9NKe4DhQDAZlJexUWzPYi+ymw632qdPCLAgWzgbNeRx0Pdxiy36mkZOoV0hkMRSIYczWsbHe2tvO/S9WjAdnQAWDte2rAAAdNWGnqOlL9nOEStKzMe7kXfOmYkkm5VQOQ002v0NWXiHDMKik4mUsSCQHJLKbbpFH7tr72FJz9Q70r9NxkMSW7Kfw3ESIAqBXZX8eVS5ZAdWMlyBc2UadDVhweJZkkkeF4gBssfeSMNcxMjjKBpa1hTTszh0WRGMgjFmKsVZiwuPs8ig3J1NrnbyuLNxzEy91dIC620M9ku2wywqBm162NKzNXVcjEqIXs4sMYUh1DTECOIgSSIQTYZjZVOv3h6b62RpJHLRxZe9X/5mBt4QQCFS5seYFNuz3s7lmH27FIWAYLYo4dgM1ka+XTTU8hvWl8I4Lh8ImSKNY13NhqT1Jpy6N5Hqb8+fETPOo7IqnZDsQ0TCfEteVlIZRZhctmLE20Pkthqdxa11WNVFhYAVWO1Pb/CYMEM+Z+SL4m+XL41k/aD2n4zEErD9gnUauR67D4V0YwjDgySlKb3Ns4t2gwuGGaaZE9WAv6DnVC4z7ZIFuMNC0p5M3gX66n5VkTxM7Z5HZ2O5Ykn5mlo8OBUc/Aix+JP8Y9ofEsTcd73Kn7sQsbfxHX5WqrPAzEs7FmO5Ykk/E1IBP7/AL8q4R/f9+dC5NjFBIbR4UUoIqWvSbyC/wCn10qi6ABXT/f9/Gl4OHyvYhMoPNtPpvT/AA/BVDfaEseh0Hwt+tC5IshDIvUUKuIwUY0yfID+lCh1l0XHjUzHHxRlmyNmzJc5WstxcbGxqG7XjusXEYvsyYhcp4b3LA3t5V2hXLh7cV7vuzUu5JcD8GBlZPAe+k1XwnTLbUV3jUSnB5yoLkC7WGY+FtzvQoUrJ+IviHHuVWNzIY+8JexiAzHNYCKMgC+2utNcOxM8UZN0E0NkOqjNLrYba867Qra+/nwKj7K8+JoeMObFiNtU7knIdVzZl1ttfzpj7QWIhRQbBgbgbGym1xzoUKxY1/sj8AX9x9wo5cDAV0JhhJI0JLBSxPmSST6044sgGHcgC5VuXrXKFIl7Xzf7hFH7MxL3OKOUX7wi9hewUED0BJ+dQ3Dh3iSmTxlS+Ut4sthpa+1coVtl+Z/9SvzfUbdnxeXDA6j7Ya66AMQKmePaIQOlChR5vxo+e7Kj7JXOIKFghZRlN5NRoffI3FSfBpmTAYtkYqwZCCpINyDc3FChTnvH5/cEv2FULw+NlGViIiSNCS1ixJHXnQ4lGEwjlAFJUklRa5INybb3oUKwfmXxCfDGHY9AMHinAAYM9mGhFo0Isd96n/ZogcGRwGkyr421bb8R1oUK3YV/t+f2E5fZZoS7GqN7SMS6YSUq7Kcp1ViD9K7QrrIwHnOJiTcm5O5OpJ86kIB+X6UKFJY6I65j1/8A6oDb++hrtChGAO/99RQ/v867QqEGmIOnwqy8BhURKwUZidTYXO3OhQpWXhBRJzKM1raf60nxFBlXQbdPI0KFAuS2R+HnbKPE23U0KFCjAP/Z',
                width: 300, // Image width
                height: 200, // Image height
                fit: BoxFit.cover, // Ensure the image does not stretch or distort
              ),
            ),
            SizedBox(height: 20), // Space between the image and text
            // Text describing the steps
            Text(
              'ตะโก้เผือก เป็นขนมไทยที่มีความหวานมันจากกะทิและเนื้อเผือกละเอียดนุ่ม ๆ ซึ่งทำจากแป้งข้าวเหนียวและเผือกบดแล้วนึ่งจนเข้ากัน ทานคู่กับน้ำกะทิหอม ๆ จะมีรสชาติกลมกล่อมและหอมหวานน่าทานมาก ',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          
            SizedBox(height: 50), // Space between text and buttons

            // Like and Dislike Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Like button
                IconButton(
                  icon: Icon(Icons.thumb_up, color: Colors.blue),
                  onPressed: () {
                    setState(() {
                      likeCount++;
                    });
                  },
                ),
                Text(
                  '$likeCount Likes',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 20), // Space between buttons

                // Dislike button
                IconButton(
                  icon: Icon(Icons.thumb_down, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      dislikeCount++;
                    });
                  },
                ),
                Text(
                  '$dislikeCount Dislikes',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 20), // Space between buttons and the next content

            // Center the "Open Page 1" button
            Center(
              child: ElevatedButton(
                child: Text('เปิดหน้าที่ 1'),
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
              ),
            ),
            Center(
              child: ElevatedButton(
                onPressed: _launchYoutube,
                child: Text('ดูวิดีโอ'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Method for creating step text
  Widget _buildStep(int stepNumber, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Text(
            '$stepNumber.',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
