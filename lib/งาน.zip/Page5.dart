import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page5 extends StatefulWidget {
  Page5({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page5State createState() => _Page5State();
}

class _Page5State extends State<Page5> {
  int likeCount = 0;  // To keep track of the number of likes
  int dislikeCount = 0;  // To keep track of the number of dislikes

  
final youtubeUrl = "https://youtu.be/43qBCUb5WZ4?si=V6MrHTBYpy1UT9h0";
  Future<void> _launchYoutube() async {
    final Uri url = Uri.parse(youtubeUrl);
    if (!await launchUrl(url)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor:Colors.green[100],
      appBar: AppBar(backgroundColor:Colors.blue[100],
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // Add padding around the content
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center the image
            Center(
              child: Image.network(
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFhUXGBkaGBgYGBsdIBobHhsYGR4eGx8aHSggGxolGxoXITEhJSorLi4uGiAzODMsNygtLisBCgoKDg0OGxAQGy8lICUrLysvMC0vLS0tLTUtLS0tLS0tLS0tLS8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAMIBAwMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAFBgMEAAIHAQj/xABEEAABAwIEBAQDBwMCAwYHAAABAgMRACEEBRIxBkFRYRMicYEykaFCUrHB0eHwBxQjYnIzgvEkU5KistIVFhdDY5PT/8QAGgEAAwEBAQEAAAAAAAAAAAAAAgMEBQEABv/EADIRAAICAQQBAgUDAgYDAAAAAAECABEDBBIhMUETMgUiUXGBFGHwkaEVM8HR4fEjQlL/2gAMAwEAAhEDEQA/AGPIcSrTrVJKiQmZsI3v1Np7UTddgj0oVgGFeGWXkjSARIVe8GDHrvVnQEpCU7AQLz9edYuozsr8mCRLAd361ujMAqQ2Fum/wJkAjkVGEg+pqk2pRMaTa0gb0fw7egRM9zTNMXyH6CdUqvLC4vJ4eU44XHRp/wB6tZiOQshJB7GpcXw6lUKDiw4LhZMmRsYNh7RR0L71A66Of41WulxAdSr/ABHPYINV/PMSM3y9xprQ4PFleoED4RBnuFKJBtYae9D8Ji27JcKtOyVSdQJ5GLEdDTlmb4II1T1H82pKzfBgEkQJ/wCtu9Z2owhXAWbmh+JLk/8AHl4J8j+cRvwOSYdQ1EKULG6j02I+t6LqThWGSPDSEKmYG8X33JrnfDuaLbJQFGBMW5Cd53F/aijePWtDoXK0AAkFREAkXSUgwZjlFPxZEC1tFzK+LZMmLL6ZckdwrhsxS3pVhQdF/FQ4SCQecGwSBzBJvJiJoviOIkJTKgZVGlIItyIJm9+1czzXWghxpZcRbU4PsLHJxP2TCoMCCFT1FS5dm6W1iEzrEGySIVyMi8mOfKkply4jx/br+kwhYnSGMUHka277yk2UCN+xqo5ilD7JB6RS9l/EzrDrjXhNlQUqUgEyN5Gk2IF4pwweYs4hHlcGqOkKB7pNyK1dPq94AfuNQ/WCV4tX3fpWqcQo+s7bW6gm1S4rxkKKSlHrJv32qNAeVyQB1JMfPTVBMeBLiM1SjRrX8Vt+siem2nreaQc1dWzj3A0salaVKSSAHExZaZ3PK19xTBmnis4tc6iy6rUhWkqSJ3SSNgFXE9TQvOclbfeAW+PKZhR0uI3OkFQ+BX0padmEaAuMeDeU4hKk2IstHPV2kivMywwU2lKQQtJtaSZ3kflVJ3GIaUnSUkQBCDMW2PM3+1V93EghJVCZsknn2BpjWOoGOieYPYZWlyVDuQZ39KIOYszcfWomnkBXnJAE7dalXiW94uNriosuqRDTS9MBPIEpZopawkJMQZuJk8rGx96ot8QPBRaeaCiCYVoABttYfhFEHcyClnypIBsRKZ+sWofnbIfKA2dJUU7b96erWLWe9MA0wlleI0woXSoBQjcA8vUEEe1Wv7hLwgquI843HTV978aVjjylYbQsykrSCdlQrYjaD+NXcrzNKifsmfMnv2HWuByDzFZNNxuWW8Yp9pWlUnmCBIUOoNVFYl3or5U2PYfWwqPsjWk+0n5j8qkyXBpS2HFXWq6ZEwOWkdTvNG77RZiFcVdSplWTL0hbyimdkWmP9XT0ouMM2kSfxNa4h/Tz8x/l6qhRUbmpTma+IstcsKcH2UD3rCpPS/afxmtNSRzrUmmDIfJnrmKQjor/AMav1rK8FZResZyzMW6sJJKfKTAgXmY9NudatJCipOkpiLkzPX0oU0+4AHipxaCgFUDSN+XW29b47NypoqaS0TvGq466iDzH8tWFuJau/v8A7+Je2NQOYZS3pg2JBtzgVM66qJm5Bsdvel3hvFqjwwnUhOnzi91DxDc7hIUPWfWr+ZZiEEAJKlGRcGPSa0dwxr9JnEi+JfXioEQb0NzN1QAKYna/4diaA57xkhtOmAXB3EJjqRMenzpeT/UxpSih5ohJsVoMx30n4vYim+llZCV/EIcw7jc0BKG4OpQUdBO4EyT2EEX6Vs28lQSCD0I0zcdAfWgmcvjxsM+glZIKErSZSpKwQFXEgykpPQgg3BqticzWmXE30kgA7QDc263NQ5HyFl8f6HqcLkdQy9hGJKmVr16bpI3E3M9a3ZcU1h34SFEoASFbQVAG8iwEnfcUtNZsrxklaYKh5YHNRAHsRNXc6zIMsqSRq1KhA3hUFU+lhM0YDqfqYDuztbG5Ll2ZLDTiVN61wkFYEiJUkxpABQlDih2m1W+FsQ0XCXktc0gI3mUkeoESKVMLmOLQ60oayN1HZPmgx0sNNXsNgXcO8txqXPEJUtCUyUElRSO5AMQOtDqcZYFbo+P9o7HlbEpquftOjZ4UMtCEJDihIUUyTEAkkc/MN6o5YwqULcA8TykQD5AqDE8wQaIZNhHMQtLjrbgSI/4iSkxYwJ6kC1XsNgsQtSHHdCJQkLTudSZFiLREV3QaV9oLg3C/V5ChTwf2Es5sdTGvmiD/AMpMH6wfnS2MeZBgneJBpwW0jQtBV8SYsNvrQleUMjd1f/lFbdQFcAcwInHuawUrKVHcEWWOg2hcXHWIqPEYcYhSg9hwt2ClLiV6SoDa4VyPUc6MP5JhlgpLi79Cn9N69ayhvSErfWsgeVZSkLTy+IHzDsQaA4zdiH6i1UV0ZCltYC2npEW8dog+sRR95h50BrwAhqANRWgBI5bHehb/AAEXH/E/vBoJJILfmuCOSomavJ/py1BSnFuXi5CeU9QKPcR4gbVY9ywvLtJSlKg6siAZSqD35H1rUcMOKkqUQZ2At+golwzwmMIor8ZTp06QSAIBM8jFFHGVG9z7j8JpL40Y2RLMeZ0FKYrYjIy2pKSqZEwkfraqGIyxhtRdViShYuEJIUfSUggGQLzRnipxTaA4prxdKrJCuahpBVNimTt6UncUou04ogKWkF1DTaydQgSCkaZPTtN5o1AEMM7dmVsStTrzbeES3CgSrxI2O5WTJBSQfMk9Kp4kKZJcV4bwSSdTSgomOoBH1F4rfBvLUD4OFsbaFFSvEnYlO6ymPQE0cy3Ji4YxDDLPMIbQgOR3izaT1WZ6CiYqBzOE7fMPcDZsvEYVSnG4QVBLdo1IAvI/PuKM4rGjlE9en6VW/uUtgIRFhpAT8KR0B3Pc2k0LUsAG95m9Zupz2aWRHk3L6HO+/X+WrP7gmw25mhK8byJ+X82rBi4iDbne3tUwy1ObYaSRXpNrVVaWVgadj9qjLAAFotVKfNOTRvDKgXAr2vF49IJBmvabvWeqc7zDiZtakqSyrUmd1WVbmNjS9i8e44Q0gJbC1BOlAgSohInrvUZwT4tYkcudX8jwYC/EeTIbCnD0GgavnIFcGFU9ogucje48TpDeIawbMPOeVIA1GJUUiIAAuSOQFc74u/qCpwFDZLbfQfEr1P2R2HzpazfPsRjHNUFS1k6UjlJ2SNh/O5o5wzwclJ8bEQtaSDp3SOd/vH6eu9OPp4Bb8mdVQBZgbKeHcRi9K3JaZNkq0/EeUD7p+8faakz7KmksqHhBCmrBSB8ZJsSVXUbGbxe21dFznOUgaYBn7PNXYDl70MTkq8RpW9/w4JCBsLkGY3NqT+oZm3EzgazEng3OA05/bYiAjVKFE/8ACdtBkf8A21EJCvRKuRkm9l7jbYSpCkqPmWSJ1g2lJEhSZmCLUL4syxKChLKRqSpaSSIMAyJ5Ebj5U88L8JqfwSCl5QcCzqUoEoKTc+GOoPPZXOIpmVBmXevc89MLEQhiNbjYSVJbSpIUuCdJ5e9tq6I5wenHpTPjttatWopS3IgiAFalEX+7TTkfB2EwQK7qWq6lrM36gbJ35Ce5qTGcRjUEMIU4s7QJn0Fd9FRRY9TyY2bqRYHhDCNK8QpKzaNZkCEhNhysKtLzHDYedAbSZ+wAPqKUMwzpxclSzvEbR2I60PwGDXiVKS2RKRJk9Zj5wa8MmNeVH5lK6Uf+xjVjeMx9kTQfE8YLPQfOlfEYdaVFKiLEgxy+cfSqeJwqyPKR13j8q4dQP/oTRx6AeFJ/EOYjipwnc/I1Qe4gWftGqreJmEPJANovN+vY/rWuOwwSCrTKd5BAI+u1TrrKNNNL/C1K2oH5loZyvko1IjO3B9o0GGDCwVIcNo8lp+ZrMKFJWk6tOlVyq8d4FU486saEztTpjiFsBGbD544PtX96I4bid1MSd9u8bxQ5rCrfbQHNZJUNLxTBKJghXI2kg+nvtxRjWmkBAZTqBKEEavJsTcmFLtcjnbkaoDTLZAfEacJxaftTTBg+Jkq3Pzv+9c8y/LHHcEnEoCtQJlB+2kE+ZHXl6wY70mc3CgIsaMG4kpXU6pj3HHRLLyQfuqEg+6RI+RpL4i4izHDD/IxpR/3iVFSf/EDb0MGoMpzhZUEhKlKOwSCSfSKZsBnw2Kp5FJ37gjn6UJRZ1czrwZzxPEuKd8qVlAVJhoBMjmSRFu5NXcHmq2UhIVzJIJ1Ak9YCSfcmm7H8K4bEBamCGHVgXCZSY2lE2H+0gdjXNs94UxbKh46iJJCVIEoNpGki88tJAPtSHUj7S1MmJxGM8RrPJA9Eq/NZrwZprMkfK/03+U0oqyRYKYWuVXnbnsbxtzFeTiWZKwFo6yJHa1iamOPG0I7OuI1YvHhIuREEz6UNxPEKPKIJlSU2Ik6jFhWuCcaxSC2sAg2IO4PfmPXcfSteAeGWv/ivhP6lBLa1tctSgQBqjoCrbmmuLpEJi2xqFLDxOi4HBqASYgEWFEXklKZmx5zS/mGZLZfUgKhEjSJ6+u+xqTH58CgC3eNj/LUYUJYkXMncxCZt+NZQ1DiI80Tz+EfjWUmj+0LiEncvbxCUutKBQeguD0PQ9qgfyhEKSdloWhRjYKSUk/WudMZ+/hVeIyqPvJN0rH+ofnuKYMh4+ZcWQ+54JJ+FYJQLclgkpvyIitEieyY2A46iBl+IVgMWUPpJ0kpWBvBIOpB67KHI7Hc11RpSVI1pWkNlIUHOSgdiNvkdoI3FDeO+HRi2g8yG1lPwuoWkiPuqjdPPsfeefZPmgaSWcQnW2FagkmChWyikiY1cxcWB3FBkxDML8ic9w5j5h8ywjXnUpTrpmdPmO9oOwHarI4xn/EzhlrUo+RJIBuI2Tq6Ty50tMZe646G8Ph1y4ApHiWPhn4Vq/wBMXnbtyrrvCfCreGTqMKcI8yyI9h91Pbnz5AJx4CTyOITDb47gPIeBUuKGIxaElcyGxJSn1J+NXfb1saasdmDbKdKAJGyRsPWtc2zWAUt7c1dfTpS/jEKSoII8x2gzPaeoqnhBSzyqOzK+Y4pTh1LJ9On6UvY191DifDSSSIIhXwKsVWuEjfVtvTtg8kBB8QBUgiDOx399oO9EG8tT9kaQBpEcttvYAbVO9nruUIwESMPliQ55gp9KwSkAaQTMGTIB3Gx6zV7K+H28OtbpKtRsBrVYTsYN463ptfy1PxGxEXm8TJFvvGJ637ULfw4bKlFalFU+VV9EgkAIi6YtJJrLzYMyKPn483HjKGPAidmXDZUdbThUtRPkkH3BtMcx60FVl6gSlRII3B3/ABiKasfmoKQUthCUfaVYpUBzVyVB2oaxlDj0rWqUzYJlSjNzqgQP32oQSxoLU2dHqiMV5GsD+sAOBFwgBRj4j+fX2qghx1lRBSYvMi35j+Cuj4Ph3DzfDqvz0zv+HsKJp4M1AeFpREwFt3/LTy5fhVa6Y19YbfF06oicpQtp3Y6FHdJVBJ6pVFj9OoNW8GXEHw1t+IkkeZKE6lix0KISVAagCQSZHUxDcrhZ8YhKcSEttaDoDSQoOLn4YgGAnUYtt61ew+RYdLgLLqiSJnUQlPLyjTBVANtVppuK0O0n+vY/Mi1L4svzAc/t0f5+08WpTaCFnUrUV+UXBiBaYkCYH4VDhAFaW3EN4gIula2TaewSsTvtvWMvhpwNu4YzPxB5JlFxKUgzvEx+9SZTmTa8Y7hm76UakBCpBG8kkC8R5drU1chJkD6cheRGdnC6iNSxo0/YsQbQLiwjsKWM6/p5IBw7oJn7Yggc7iyvSBVl7Pg2YX5VJsQR9PnV/D5u2/BS4QeQBsfanq/gSQ4yOZPw9lKMK2AnzLI8yyLn/wBqZ5fjQDjLABM4hu3/AHoH/rHfr8+tMoxXhp1KVASmCVW2m/40Lz3LxjWChJUgqEoUJAPOD1Qa8WswFWuYs5VnZSRCiR9adMvzdDqShwJUlViCJBH+oGuTIwym5A5EgjoRY0Wy/HHkYI5U6LZfIjdnXCEkLYUSnm2b6Rv5OahPIyr/AHclB3EEpWlYsohJOjabTaCk8/3mnfJM7kQd+h/KiGa5W3iB4iEoD4ulSgYJ28w2JjYmY+oU2EHlZ1ctWDOW5Vkyw7KJIUTJ0qITtuqYi34zRrDMujOcO8hH+FMpUvWi4UlSdtWrcg7VUzRxxKil4q1JsUnl7bUJwOPP93hkJMAvNz7KBriLRnv1LEFajr/ULDw6gp3XIHrv+tIOIxTjXlWFJvIkEA9gTXUePMJ4uHJAktaVe0x/PSkLD4ogfEfSbfKu5UG64tcm0dSTDPHSJUAekA/lWVopaDuhBPp+le1N6JnfWH0i5izqERFL+NaINMbtzW39kgpLjg8idk7azvHZPU+25qvcALlx+Ucxby4LaIdClom6QhRSVfI/DPOtslSV4pA8LxFrX5UC9yZmNrb3sN6tqSp0qVEnnFgBsAOQAFgK6t/Sbg7wGzink/5nR5QfsN8v+ZW57QOtBjfexkpyR04cy9aG0+KdSwIJ+Rgc9M/M3517nOZC6Eny8+/7VJnONDaIm9I+c5nEieUk0128CcUfWeZ3mYCFAGARc9Ku8EuLcdUlcrUhtJUoiwUqCEx1CLnue1ICs08YlKUFXIDqdh867DwzgQ0HFxdxWszyJSkR6CIpJ4jeIX8K0V6taUCTYAVFiMSlIAKhPqB250ucVuvqSlDSSQTKiCASBySTYme9LZwBcNUJNSHOc/lxCET5zFjBFwJnrE/lXvjaU3PlTIBUSSekncmlfLmitxvQVOKbWdUpgAjZJPYT0250wPYllsrU9rc0CVpShRCbD4oFhE0l1VvdzKgtcCahctamyltAP+TUABB30kE+aeUc+dR5TgULcJS44vVYQQU6TfUe/UAdqp5DxMy+pwFKQ3ZYSRvsDv8AaBAPvV97inCsxBAUYSiwFiQAkAWAFLLqOCOZRscAheI0MONsjSmZ5k3v1vtPbrUAzIGI1GTBFvL3M9dhE8qAnMAvzA3qPDXWSVqSSQfKqAeQn2pYzsDzBXEOb7jfh3ErSpt0awo3kE39xA+gofn/AA5I1tIUqDKtCtK+XL4V99j60Iw2aFS1eIhJU2AEquVc91ED6HnRA8QKkDVAH6RvVDZ8YFNB9Jw1rEPNcqeWqUjUgbBVlDn85rTLsS0HAtBLLzE7pnxQbEEnYjkb9+tN/FfEmHQhsrI8RZMEdBYz8x/BQ/Kcxwzyw0q6omSk7esRakirtTK/UyPjp1sCWOJ8ubxTaXUmZg23IgTzuoX2vHWKGZDjlsOpStTSmCCEBKI88jSFGIPPnvFW8Itxp1xkMFbYUS2vQoi/psk35WtvVhzhcOkrQlTKlXUlV0k2vbnI5i1Uqzd+ZIypW1uvEX80zfFvOBLzYQ3qkoF5TPMzEWplPFjaACBqWqEpAO5NgI2570Jd4bxaPgYbXMkwNjMmY70QabWzp8RKyUgH/hpX4YsJE+YDeDPtTA198GJyYwKrkftCWaZIytEhKUuqGrUPvG5nrfrSBmGCKFE/CeY6fqKbOIkv+V1Lig3YhOnzGxueif0qrmTviYdtwpGpUJvv1/I01clmpGyiri9hMYdphQuL07cP5zq8qvj/AB/egKs2wyGA2poagDACbnvP40Jy7MSQOSkxBpeLUl2K7SK8nzByYqW7j5xPkScW35YD6R5Ttq/0qPQ8jyPauacGZUo4zU6kjwVGUkX1i0HpFdMyPMg4AeYsr1/ermZ4EEKdQkBZA1EfaSLfMD5gdqroXcm7FeZCnEa9QUBCxBHaud59lpw7pSPhN0nqKd0qpf45IU2394Ex9P1+tcfmM20Ki8hVq9oeJrKRFVIC2kgrjwRpBgkmZO/muJE29KGZjnqSoBKAUpEAKkiO4tzk1tnytTbYSQXFeZwzsSLDeLbQOlBDh+RPr3/aplW+XP4lG4t7jOg/0+f/AL57wnGUhDY1qKQAmJgCBzUbc7TXccM31t1pA/pJlAawYc0gKeOs/wCwWR9JV/zU85rivDZPU2FWpjVFsDuBS7jXUVuIs4DbodKNaEk+WJtBExzgwY7UjZw/4y9DSAFPHypAgRG8fZHOKM51i7KPIWpOyzFOB1TscoA95t3pbsQI9QKjfwlwqlvEJKiSUAk9JsPeJn2rozKYSABsBSPgcWA43CglRMmTJk3KfUzT5hnvL0O3r86QH3DmdA5iNi33FvOmYEi/psBNomg2Bzp4YlKXNYQVFKNhJ5m2w6ftRviU6H3SLHSiPUz+1DsuRpKVrJ0j7XObyR0qbq7mpjIIupXyVgreecW6s6XDovsqAFSkWJi09/em9zHJQnxFKUALGTuLCLUGyrLvDaHh6VBSlKWpRAJUpROrnptePxq3j8H4gCAknUCdW4BgbqmCPY/WjPdxbGzzBLbmFWpf+BtsKkSARqKjYwLC8cvwqjgeAdCkv4t1NpkQohMGABcG+4iiuLyZGhCFGSCLCQknkDEEnodu1a5otzSEq1FHNsEXtbfaL7UWPLXizDdd3CmhKGe47CohTDkmUpUjSobmApJIgxN77X5UTw6+YOodevpSnmWWpAJBm0wd/wBD86HYDNHmTpHmT0Jn3B/I13Lh3i1/pDRa4u/vHPMszQhM6oA5k96XTmrrh8iSEmfObCBcxzNvrV3IMm/uF+K8044mZnSChIkSYJmLi8c6bMTkKFvwFQhKQBERNwb35FPpFD+mVVs9zo1AV9oi1hMe2pYBbTKQE6lAzYyTv8RmOlF0PYZS5akOen4xy9zUGNyYMkqFiRANjbtFBjiFosEEzMwNIj3BvFcK7e4V7/bGoZs6kHmkSTBuBzO21XG89IQVlQFrdD0g96V0qUj/ACLcWmUwUwIO+8p/Wo2nirQEtgMhWk2MbGJgWmLWge9I28zxRTA6szxjSirx3DqJKhY3Jkm4Nt7U45DmpUiVPHUdrgD0JAE0MzPLSpA0oVeYMjfcCxuLUrqwrqkpSCW3hMpPMJ62gnlPpQ5sHqLamuYdq/cf86zt1SNkEJEkbnfvMiJqP/5jbIQlzCskQCmEwL2sABFLuQsOrdRqV5kgk35GByt1tV/EZqvDqUChK207oWkG0m6TeLXimoSj2fMzMuHYYVdzHBLHnwiY7KUPax9KqrXlgMlt1B7LP5g1uy/gXrraW0dyUKt77gfSrK8gDoJZxDSgdgpOmP8AmGoE/Kqkybjw0mcEeJJluIwDatSHHhyIJBHv5BR9nPcKLF0g/wCoRSE7w3i2SZaWpP3kef56JIt1Aqzw/l7TpWHUBS0xIVyTtsfaqgG8NEkqOSI0rQwpRKH0gG4BG3uDQDPOG3n1gpfY0gQBqUDuCT8BE2q/nXD6EYVzwRpCf8oSLwUjzQB1TNhzArmq82JVqClJQLSJ9yRIn0oWLgSnDj9T2xrHBWI5uI//AGp/9grKRF5ziJs+uPf151lT2ZV+g+0EO52rbYdBH4V4w8pxTaADLqghJ7khP50JxXxqBvBI+VqbP6cYcOYphJE6XdXppSVT8x9aaMSCuJmlQBc+gMqw4QkJSPKkJSn0SIFV+LHIKE9B+NEcCNv5zoFxWv8Azr7ACqHIAnMKFhxOd8UYiAG+pv7/ALAfOouH8IonURpSTzF47Coscku4z/Si/ryA+lMCFKWuANRVyFo79gN5rH1upKnYs3tB8NDjfl6k+X4JIeDgm603URO45cvlTBxlmeJYGplvW2BfQCog/wCoATB6jaDNDcswrYkFXiuJIgJVpRve8EqIv2orisK4lC0kpAgnUVC49BB7b+1TYMjiy3P5jtVhxbwqiq/buAcWDKnnSV61AhIF4MJAjqmY9RNLmLzB5584dlqEghJUqYA62sbXj96OuNr+wISUkCDsABqJJNiZA+VRcOMqL6/MAEabFIMgg/DpgJjyxY2mqMThjbT2bB6ePctS/isy/ty22lJWpQ06rhJ5QZmFfjRfDY0lKmkENuc/hUU7RImNuXvzrV5lSlbSQdwORt9RSdnrQwS0LSqStR1JJudRMkkmeZ+VMKmSY9uTjzGjMWloUQEgoUJ1qJAT7/w0Ded1AhahuYUBtflG423qR7OUvoLDp0SBptM7xI3EfLeakY4L1NlSHjO9hvzgdK8ACbjQAg+cxcxTK0KvLiSfiEmOW37fOhv9qvxvDRtpkECAIjcC03A2m1HsA2tKyiJWDsAQe4I9DvzpnwuXJWn/AIaQSYICbgzfcRa/anjIQKM477TBmS8WDDMqbN0rTKZEkFVptHy70a4YzJLrNusqSQJkzJtcEm885rDwlh1kFYJ5gTaN4ty7VrmWIbwihpQNThghIEhPKfc296UXPA/ggE42vaOYRdUjUJEA7kWMdjtM+1JmbsOtuaka1tLVI8hBA6LCU8j1nleirGchTRUshIFpvA9t57b1Vaz9krWfEKkpnRqMTYSTznl2ol5NETyhlFiUXeIRZC2EKHSR+MzO/eos1ZUtClMJUEhJIQomxKSLdSDBB5T8reN4oUgAtsJUCoohaB8Q3BAjvvRDENFTJW/hm20hJV4jaiAm3wqSTCQRzsBFzTKN89QiQACOPz/pA/C+fIxDAbUVJdT8JPUC3SRbrUmZa3GQXGFB46g2psEieZ8s27GPciaD5hgls4lDjElIChsbdQpMSCOc1UzDN3GVIbe1pCSSlxQMk7mLRHmIIFqVkwlTSzuLIjHcTGHg9Qb1lwJUd1ElQUAOiYIPpIqrxJj/ABh4zcaAdBCkjlMGCJHParuEd8ZtL61qTAsu2x219pG3eoM6QlTA0QpSlCdMWib7gfUbil4xuYBoGsKlSfML8HPYfHMaMTBKVf40lwpVpgbFKgqJ1Wkiw7ULzzKlYd3/AASWlKOlUQRcnSpXbkTuPeouCcMhbiUBPlQFE+QwogiNASDcSo3Mqv0rbMM1cdWtHmS0FmEkQbH7V5F5MVcqgHgcTIBMlXn2IZAKXCesmQPz63onhOPnYSXsOpQUDpUU/EBAOnUL3jY0p5g8kJI3JBAqxl2YF0NApALZ35kkiTPsIpuxfEHcQOZ0PA8Z4Zw6FJUhR+yQQfkoX9qVnOAmlKV4GKb0GYbWjTAPLWkmf/CKccflDbyQVJFxY8/5euR/1NfxGHxLK0OrSVsgKKVESpBKSSJg+Uo+VcfGfrGafOQbXiMY/pS5yeHspP5kH6Vlc/b43xwAHj/NKf0rKT6Rlvr5vr/YQDmSIeX/ALp+d/zp9/po2GsQwkjzuhbh7ICSEj3nV8qTsK0HsSqfhGpSuyUiJ/D5098JNan2cUTe4HdKgRPrZI9q6W+dVP8APpM/K1JU7Rlx+H2pc4rX/wBpc9qPYBW1A+NUhL+on4kg/Sn5hYh6NqnN28f/ANocQALxcj167RRcYopHkABm/cRF+3agGWEf3DylCZ8o7Xm3yFFEkibSNv53r5/WAepQn2mgW8ALS+zjSlQXPOaJZrmOoiVCLEzt2FLbKApRML0puTpkD12q3juFH3WCtDYUFWBQPOB3Tc36dqXiwWYrVMgO7yJTzDiltCHEKXv907yZsPtEwB0Fz2MfDWPDanDe4CjB94JOw/IUJy7gLGFSVut6EAmFOWJCZVCUGSCYMEinH+0w+DbW0G1LccMlUBao3t3773n01AMeMbZks+TNdDz/ANwtguJk/wBup4jSPKBNydySB0IiJ5GaXG1f/EcR4pJDbMXj4nL2/wBqevMneoMzfdbltxSUtkiEgSqNKU6iI8oAQQP9vvV/ALSktoRDbMaUpAiTY6p5mD151yzVzmwLe2As/wAQkOECDq8oKbbbgnnf0q9lOeOsCClSk35yB8je/KrmYYFGrWTImAbxq2vIuapYrKVB1taFwAT5RIC53kbHnc9qEUeI4uu0CRYTN3ytzFYRlpN4WSi6tp8wMxt8qu4Hj3FToW2jUT8M3uTyBFVMvxBwniBUK8U2A2CrAk2vEj1qhm+COsHXK4lCpEf+WwG9PCI1RB4JBAqPPD/FiXVqGIIaGlBSdKrrKnNdwSAAgNm8fEelj2YYfDPQpLrZg8lpn8a5eziyy6pjEgFUAhaN+Xv8p+VGV5k035NMoKZBuY5weR3PPeKYFCcVJzj3cqZvxHlDRxOltxCUqIWokiBIIcTayTqSld9/FV0FQYZ3CtOFKZegSpQ8ot90q+KdrQO9CcRmrY1aEJ1XgGxt0tvS+cWrWFqBtvpINto9aLk81GohC7STUaFcTNDEwvCkJSRADgPvBETcc66MzxHh1sF1lRPVJEFJ7j87g1xPNVJPnSFSkC5IG0bjcfy1Zl2YKTPmIOgyOouo+wAmmiKfCpjK7mjq3l+BobSbARPYwJgAbgbCYFgKmzUjw/8AL/k0R4ZI2Xtz3G1u1KmR4wB6SCpFxBty3510JWCRjcODqhPKO1qzsoYPZMv3IoXj5ZHwYhKtYeOoaAdOlKUEK5HSNwL957UzowGXlIBwrYHYqA+h2oHgsEGWtIMjr6COXPvVppdqzc/xF0ICT36NMpLNGfDv4ZpADYSgWH+Mf+o7mtM7ylnGtG4SsjyuJ3B79R1Bpe1VJgsWULF4SogK/X1Fdw/FnL044isvwtdtoeYg5pg1Jlu+pJKSSAJIkRY2E868ylBFxbeKeeK8uSELdKQHCRJnfYbc5pdy/LSoJI3JiPU19HjYETCyWODOn4A+RE80g/OuZ/1hyZx9WHLKNWnxAoylIE6IkqIAuDXUm0aYHRKR9K47/V/EL1MAEwFukfMW+ppjQcHcAs/09xKkg+JhxPLWs/8ApQR8jWUJRneIgedVZQcSvbl/aTNYHQ2G02XiFgE/dbBifnJ+VPeXtttpQlJgIIA52t9ZmkTOAUrTClHSIAFtvNc8tx3q9lmaqNnAR35H9DWfZIDfmRsCwndctdkA1W44w+tttwcvKfyofw5mIU22qfiA+ex+o+tMuJw/jMLb5xKfUXrSYblndM+xxOLAJbfUlQnUDHK/X+d6JYVskfHHa9TY3JfGXBV4a/smJ8wNwR3Tq/ljEjL3W9RXHlUU2PQA6vQz9DWHrMdHdPsdFqVZfSvmXVMpbVIOsqAN9gecD8zRzh7OS2fDPwqJPv8AvSwp4KAM3FWcvQoqKiNQSJN039dW/tUCF94IMq1GJDiIeNHEmPASJVsCY+X5SPek3IMap/GqWgqHhgkwLGZTpJMRqTq+Xai2O4SxeNKFOK8JqQCJSJRMzAJMxyJ5Cj7eQNYTDpQyPMnSVri6yOZ99hyFq0mXahfzMRXVax9xQ4qZSpel1xxMjVCCUbkpvpSrUfKYnraxrGsrQoJKgVtpSAk76hyOn7J6+1yIodxxjnEqQE/EVBR7JTISkT8UlRM/6BzmIsRm7iUNoaCjqSTpkAA2KgTEjTIsBzB52MByAB5jMhXbfkS3nDcOIDhWRMISNMI3HoImiKHSwGwtUggJi5EDmSfXoKU8ZnTjCUzDiiZcBGw5AK6m/wAhW2bcSIdSnRrBMQFCN7RIkGu+i/U4HU1fUvZ62945JRqQgFSEk3WkFOrtI6RsKgdS2t7XBSnfSpPwkWPLrytRDM3HmP7cq/yxJGlJGk6YKZNjIO9jva00EznMHHA474YSSgAIFysaom17Xva3qKoRDVHgxG+uRyI1YHLGMYoJcUFLC0hN7+HoTz3J1ajud7V6/wALYzD+IGEpfauoNkwsDtJ8x7TfoaUMuxpKkkHSREW0nfvMGw2pyZ4sc0eG+347ZTpWsC5SbEKA3nte9MDA/K0TkxMnzY+vpFHEP4ZclMod20KsARuDO/p+FeJw6E6lHyOTP3hz6GetNi+F8PjnXHgoJbccUuw8w1BBgzsQvxdpBCk85hU4o4dcwSgdRcYJgT15A0wpPJqATzKBIVqUsgDsDc3PUT+9F/6cZSH3cRqHlS3oIP8A+Q7emlCh70MeZJSkN7SCI3BIPXYTa/7068I4ZWHSuRHiBCpkXsTyJ2Cve1BuqFn9vEHYvg1Da1Kb23ieXTsbb0yZDmLJbCUrhIgKCjBB5g7W3uLV6qXNUyE8zzMch+tDsZgS4dDKQEi0/kDU+UqxnELFaYzfN8zS274emU8ikjblbaIq9hErW2F7naJklPI+sW9qjweQtso/yqTA3JgAdpP4VvhQzf8At1aj0lUfp9PeoM2kVyRUtx59oFT0rI3BHrUanagXnKgdDrWr7wJuO45x70YcytlaAQdM7HUT8waiPw5geDxKG1iqPmEH5w0+WkEqm8FMSVCZTeOQBq9kWWOodbQsJukKEKk7kXjbY0s4tzFh0NKcCtBlJi2252JAHXan3gvDk6nVKKoHxHn6dByAr6LTrtAE+d1J3WYbfVdRrh39UnVf3CEWOlKlcz8Rt6WFdqxa/KSTEzf61wTjLFB7GOqJ2Om3b9yarbmJwAgwGmY5fKvKnEfe+n71lDtEr3GQ47GqUXIAkOGOXUcuyRVD+/cJi3y/erGZHw33UqBPmO3eSPxqoNJNj86nRFocSMfadJ/pdnmvXh12I86L7iwUB6WPvXXssxUgKFfM2XYxTDqHUyFIMgdRzHoRXecizZLiEOIMoWJ/UeoqpaAqKyLtO4T3jPLyg+K2LLMg/dUL/WuejHnxnAXCoqOpVogndMc42nnFdnDSXmy2u6VD5HkQa5NxhkS8O4VBMqT/AOYdff6H1qPVYN61Nj4bqhjez9p6IUAUwSek29eUmrmCQNd4EAzzk8hPK97UrYTiAK7Gbp6H9e9M+V4iW45K83uedYeVDiHM+kGQZhwbEYMDm7iU6NRgdb/jV3McyCWiVGZslI+JR3hIG/r86AoYcIABEeo+tXGWFhoDWNUwogEgDfdV1H5Ch0rPyCeJBqsWMEEfWc5zpt7xfFxLbqUyVK8pBM7JTqFhy7XNRt4pfhqWlXmAgcgB91Ig2kkzuSSSSSTTXm+Iw6FForUSsQUqBJM/8sT/AMtUcJkykeZVkXiQZAPUC5+QrTOpUDmSjCzMD4gbAsoIKnk6lqmBFuVzaxHID2otg8nS/wCVSRpgnb15WrxDS0q/xAPJFyNon7vSiGFzhIN0lPW0/WvB75ue1GQJazcZO2NIKNUCE6jOwm+qRy9b0KzDEkplITqQmJFz9skaYhKQmIjemHD5iFWBSZOxImaixGXpUsm4UqNQtf6fXvXd5u5PjdfMWcuy8eEtSlXEeGgQVGfyIm30phyNvSgAqBMyoKGxOwFwPfrPoCLbDSUoQUmJHKZAEfw39KAoytTLhDROgqkX2k8r8resetFuJ7jC4axcMKZLalKZWptZudilQEbj4Z722FB89dxeIT4TjQcFvhKQbxFlER+9HHmZ0NrVocWhapHRJG/QgEWNUG8C6ApzWlRT9onYQfSbnnO1NXIRJyinkxLYbfZlDrR03IKyBE8952n+bt+R4jxcMmSJBI1JMjSJ+smI7Gk7MsWXCYGqTc3iASd/QxaOtMmTYpoaRqKEBGnSSI1W8w6c7RHyruU8RqoWFdwriswMCCbe/wBete5DjFuvmVaW20Exykxy52BNZluXtuFSC6ZAkQBcEwD35TFU1YpTRW2pCUrSSNSefQjtBJ96QoBMImhVSbN8et52IOnUUpBtsYk9z+lb4XBlHnCwk8yII9KG/wB2VuFWq+87RYfWiKFylAPPUT61xzXMZ4kj2N1HVBJFvWDM3q7h82SEg3TA8wiR+9Uy0mKqMo8VXhp2J814sJMTymPlJ5UOK3MlykVCuVqU9rcUJCzpbBHLtPKD9a6FhsKGWUNjc3VQHhvBBStZH+NFk2jUdyfcztRzEvTJ5natVE2zLd7gPjHMgxh1rMWBi+5r59dd1EqJkkkkxzJk10P+puZqfWMO0UkJPmBPy+t/akvF5KcN4S8UUlCyfI2q5AANzFtwLUfcZjKqOYLL3r9ayiBfw3LDNx3cf/8A6Vld2mM3T3jFkFTWIT8LqAfeP0I+VA4BMkU0YNBewjjB/wCIwqQO1z8t/pQjCrBHp3qLC9Db9P4P7TuFLFX1KAAF7+804cBcSBpzwFq/xrPlP3VfoT9fWgqo7fX9a1S2NwkT/O1ODw20+4Vc+g8uxkRyHKr+bZejFtaFQFj4VfkeorlfBfE8wy8b/ZJ5joe9dJwOLix+dOBDCZ9NiejOJcZ8OOMLWoJIN9Q/Pv6/wOGGxbC2klqRYRz/ABro+b5Y1i2ylYGqLKrlOP4cewTkRLZNu37dqzdfgLp9pufDNSoeyauF2lKEXJvYRvRZttUlRP2Yg7DYmO5gUAGaIAhKpIHPeO1aYnO0IQpalRFhPPf9qx1xupoTWzMHFngQktbYcU4UjXzVz6e3tVFzFqdVpHPYUlYrinUTCTEWvfnHtPKjfBanXApQSStRhB/GJjbrRnR5ANzSdtbhQEIbMcMBgQlpBGlShq1EGxBUVD3ExUGOylKvMBB6jn+tG8Fws4kSp0hVjCTI6x5hNus37VUx+KDbnhL2IB1coMi45bU39Qm/0z3UxMm5rcxKx2H0HzCO4qzhHnF/CFLA5gEx6kUXzBoEERI6dO47UR4axwba8Ndo2UBAKR1703K7Y0LAXAxm27i8vFvNiIIB3SZTIG24se4qrjs7UbBopHUKn8KaeLcWBhyDcqKdPzvHtNJHid65otS2ZNzLXMdl+RqltebOOgBUEfIztv8ArQtODdfUpJUIQbp1GSOoGx2FWWRKtPPcetbLUQdYssWnqOhrQD1HINw4lF3yeUCDUBwp0qJMUUx3nuUwao4vCrH/ABDpBEgD4lD8veiDcTrK27iE+FXEpCVEKEkg+axTINo/XlyolxKga0uzIUkJ9CJ39RQfLELURYI+ykGwFvwimPiLFgsrTCVReQBCTaNHuTc71IT89yhh0IAwrRJsN9qNYZmShHPc0FwpJvTNhcUlDcASuIrmXngRWTJtEqZtAUEAxO88qO5JkaVaEtrUZkvKIAA2sn2/gJNVco4bViFa3R5ZmTt+/p+PJ6abS2kIQISPrV2mw7F5mZmy7uAZsEpSkJSISkUscZZ+nDtEk+Y2HOPaiOdZqhlBWswANq4fxPnS8S6VmdI+EduvrVDNU5gwlzKmJdSHVOh0q1q1TIB9CDe1VeIseHUo80lJNpkgEDt2FUXiedVHK56lx7YQOZqFmvK0NZXd0VUf8whh9OKSRoV5XRfYwJ6WN/agee4TwHj9xfmTHem3E5WAgo+JpQi+6ek/r6UCQyXmVYZf/FZug/eTy/SsvC9c/Tj8f8RWLJtNwKHE85rcuJ7/AFqsg8iLi0VYDkfZq/iaKzPFAIifrT9wdxqDpafsrZKj9rlB6K/GkHxT0rNZPIfSuhqgZcQyCjPobA48cjIouS28jSsBSTXCOG+MFsEJdJUjqN0/+4fX1rqeUZuh1AW2sEHoZH/XtTQQwma+N8RgHiz+nUy4we8bH+fya5lm2WLSdEkK5hc/iR+NfRWGxvWoM1yLD4kQtIB5EUpsPlZTj1XG1xc+Zv7derTee35RT1krT6MO2AhQg72F5JuJkb702f8A05Uy6XW16h0N4G5Hf6VYOLQ0kpW2pu99SbHlIV8J+dJyKaoiCzi/llvA8byAl5BQuNwJB9IuKVcyxjz2K8YJIRZIGobdSJ59KhdzBhClLWSSTMJEwP8Apyoi1meHKRpUCFAH4dp6mbH1rMGlCucnN/zqE2axtqEcRhjo1JHm3t0oThcTHmG2yk9P2NGMkxkgxcAwIMx60G43b0BKmnAguSFIA8yxbY8h1/Gn4gSdhiq8ieOoaRdRCkD4byReNPY7CguYErJLYhP3YGo9TP5VeyDgvW2HHlFCDcIFj0vOxt61vmrDbS0pSpUHYn8CetAM2NcnpqbP24luPFa7mgZnDLkJ3nbeR3EcxRR9oWQv4vvbTVa6VBR5c69xhbcEnWD/ALgfyp92YxcbIbE8LDoEtq+R3qJt56NKkg+orXDIQgeXVNrhUfMVo7iHb+Y2tsLfSi2k9SkZKHIl/BoXN/L3t/Ir3NMUkDwknUSfMQbCDMTUGCyXE4iAhClA8zIHr0j0p2yL+nukBT6r2MJ/X/pRppyTcmzasRTy3CrcIS2klXp/I96fsj4TS3C3rnoKYMNhG2kw2kJ7xc1j2IG5NVY8Krz5mc+VnM3WsAQLAbAUHzrOkMIKlqA6ChPEfFzbIgHUu8AVy7Ns0exCitRPYcgKJ8gEdg0rPyepPxRnjmKXcwgGyT+NLz6e9WVpJgn5H99qo4hB5mkE3NNUCCgJTdqqs1O4O9V1gUQk2QzSsrKyjk1zqPCSyWUSSbc/WKEZjbGtRa6hbpe3pWVlZKe9vzJB7z+YGz5IGJcgRVVqvaytDH7BNPB7RPRXorKyux3mennRbgx5QxaQFEApMgEgGIiesVlZRL3F6j2H7Ts2XqJSJPKi+DUZ3rKyqZiiEmjWY1sEXAMm9t6ysofEaZx3+pODbRCkNoSSsglKQCb8yBSa2aysqZu4Rl3HvqQ0goUUyTOkkTYbxRfhNwrxuE1kqjT8RnYKI3rKyujqEOp0TiM7+n50n4wXFZWVhr/nTRX/ACoK1GT61qUiNqysrQEJOpEobU48D4dCgdSEqg2kAxflNe1lV4u4jU+2dJwyQE2AFaL2r2sqwzPHtlJ40scVOEIMEj0NZWVydxzj61kqUSSTqNz7V4/ZNrbbV5WVAfcZ9Gvs/EpOuHqfnVFRkmaysp0kySJYqFysrK8Ih5FWVlZRxE//2Q==',
                width: 300, // Image width
                height: 200, // Image height
                fit: BoxFit.cover, // Ensure the image does not stretch or distort
              ),
            ),
            SizedBox(height: 20), // Space between the image and text
            // Text describing the steps
            Text(
              'หมูกระทะ เป็นเมนูอาหารไทยยอดนิยมที่นิยมทานกันในงานสังสรรค์ต่าง ๆ เช่น การรวมกลุ่มกินข้าวหรือปาร์ตี้ โดยเป็นการย่างหรือหมักหมูไว้ให้ซึมรสชาติและนำไปย่างในกระทะแบบพิเศษที่เรียกว่า "กระทะ" โดยมีน้ำซุปหรือน้ำจิ้มต่าง ๆ ที่ใช้ในการทาน คู่กับผักสด และข้าวเหนียวหรือข้าวสวยเป็นเครื่องเคียง ',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          
            SizedBox(height: 50), // Space between text and buttons

            // Like and Dislike Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Like button
                IconButton(
                  icon: Icon(Icons.thumb_up, color: Colors.blue),
                  onPressed: () {
                    setState(() {
                      likeCount++;
                    });
                  },
                ),
                Text(
                  '$likeCount Likes',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 20), // Space between buttons

                // Dislike button
                IconButton(
                  icon: Icon(Icons.thumb_down, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      dislikeCount++;
                    });
                  },
                ),
                Text(
                  '$dislikeCount Dislikes',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 20), // Space between buttons and the next content

            // Center the "Open Page 1" button
            Center(
              child: ElevatedButton(
                child: Text('เปิดหน้าที่ 1'),
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
              ),
            ),
             Center(
              child: ElevatedButton(
                onPressed: _launchYoutube,
                child: Text('ดูวิดีโอ'),
              ),
            )
          ],
        ),
      ),
    );
  }

  // Method for creating step text
  Widget _buildStep(int stepNumber, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Text(
            '$stepNumber.',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
