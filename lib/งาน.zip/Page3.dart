import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart'; 

class Page3 extends StatefulWidget {
  Page3({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page3State createState() => _Page3State();
}

class _Page3State extends State<Page3> {
  int likeCount = 0;  // To keep track of the number of likes
  int dislikeCount = 0;  // To keep track of the number of dislikes
  final youtubeUrl = "https://youtu.be/zLpT-JiPPQo?si=1ZO1m-T6UQ810XMU";
  Future<void> _launchYoutube() async {
    final Uri url = Uri.parse(youtubeUrl);
    if (!await launchUrl(url)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor:Colors.green[100],
      appBar: AppBar(backgroundColor:Colors.blue[100],
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // Add padding around the content
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center the image
            Center(
              child: Image.network(
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFhUXGBUYGRcXGRgdGBgYFxgYFxoXGBgdHSggGBolHxgYITEhJSkrLi4uGB8zODMtNygtLisBCgoKDg0OGxAQGy0mICUtLS0vMi0vLS0tLSstLS0vLS0tLS0tLS0tNS0tLS0tLS0tLTUtLS0tLS0tLS0tLS0tLf/AABEIAMIBAwMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAEBQMGAAIHAQj/xABBEAABAwIEAwYEBAQFAwQDAAABAgMRACEEEjFBBVFhBhMicYGRMqGxwUJS0fAHFCPhM2JygvEkQ1MVkrLCFpOj/8QAGgEAAwEBAQEAAAAAAAAAAAAAAgMEAQAFBv/EADIRAAICAQQABAQFBAIDAAAAAAECABEDBBIhMRMiQVFhgZGhBRQycfCxwdHhUvEVI0L/2gAMAwEAAhEDEQA/ALfwrEhzDtuD40AT1EXpbxJnIrNcgkqkDbcKNyYB6CwPOieAtFtCJ0UCD6kxTB3DBbKZE+NKTeLZ8uteYLIEsbgmJuEYlTGIAOivCf8AdofePnVi4tjsqDBg8rz7Ug4hhpy7G6ZE2gkCJ9K9dxYdTc+Iai2tZjybbUztt8yj9rzlcKZk7xpPnvVPdbKt6vHGeEBairOZPSkzvAo/7nun+9L8VAeJSDxRlbyODRR9zTDhXDMU8bLyo3WRb0/Mas/CuxyiczskbIiCf9W4HT3qzM8ONhlgDYaDyozm49IlyB1FXCuEoaAiVK3UrU+WyfSnjGEO9qKaw4QPvW0k6e9IPMVuJmmQJrUydBU4bAuTUD2OQN58qy5oBMwMbk+9SNM5pywY5X+k0Z2dxrclbgBsYB2uOdWjC4pJSSE5Un09q1Cr8BqhFSvYlWb4YqAVeHeNj0nWh3OC4hV0RzsQE+02p88UBdkqXM2myedZiEOupyyEAzOU6jkT/epioYns/tHK232+cSfyK20ZsQUII5K1jcchSZaUrUHDYkARziNEjaRTtzgDsypc8sxn21/c1JgOCoTJz5lHW2vTXSlsuXIaC1+8ejY8Yu/pEbnDsxvAHPfXWBpXuKPdJ2IESI1ANyP12p+6lMxGn7vQmK4WV+IG97HrU/gZQ3HNQvHU9xXhf6l2/F5ajoeRrcOKSSD7GhVlzDq7xsGZCcpmwRM6iCL9KtbLrOLQMwyuDca+fUdDVaZQezUjzYynmHX9IiC0K+JMdRW38hm/w1A9DrTY9n2zBUJI3NRcT4fkGdJjSR96aHNWwkwycwHDY95g6kDkdKsnD+0KV2X4T8qQtYz8KxmHXWtlcOSq7R/2mqMeVh+kzSAZYOJ8PafTC0hXI7jyIuK5r2s7KvtgKaBcbBkwPGLRdP4hfUewq24PHLbOVU+Rp2ziUrFqMhXN+sNHZJwZeNtetm8eIhNz+tdK7YdgmsUC41DT+s/gcjZYGh/zC/Oa5O3gXsM6406gocTEpO4vcG8jkRNaMSkQnzH0hC+Kr02phgMWUpvqb/v2qutrOoE6+5qcPLEaC33NF4Yid5JjVePck3+VZQffJ6/v1rKHZN3TuvE2wlKQNoHtFHow/wDRV/qHzULDrS3HqzgVYQmEJHUq2tl394qnGtmc54iHHYHwJI/8h+sVQOJYgtvupGyyK7ErDDK2mOR+9cT7VugYt+//AHFRUurTabEbp2s1Nn8VPmbADUnkKsXB+AFEOOjx6hOyPPmr6U07A9jyhIxOJH9RV20H8CfzEfnPyHXS08RCUDrQrpyF3NNfKLoSs5K9y1O4mTWgTSqqDdwYsSZNbkVK4QBJNBuYoEQkEqNgPOuucBE2NxZUfoKKwHZ594SE5RoM4UCfIRp1qz8K4F3RBTCnNSo7cwkbVZ224vc1Ri0+/uc+Xb1KZwvsu82oKURAMlIvm5U3e4c8qxIA5jYbCNqsgvtWBNP/ACGP3MWdS8Q4XgZB8SiR5/2o1WCEAAab0eqBrao1vo0mmLp8WMUsA5XY2Yk4tw1ZgtmeYF7eVAcKwKkuiTMzoftt61Zyxuk1Cor5fSaBtLj37xGDM23bAMRw7MbJk1qnBZTBFue1Nmk+G5iagdCha8Womwr3UWHPUV8Q4chxsyNrKF/+RNV/B4L+XxCUwZWYt8JH5hyvHzq2he0gxty/vpVf4m6sEZkjMlWYHyuL7TafWvL1yItPUpwMWBT0MdODLaocUyFJI50JiOLNwFExO0GZ5UZhXgoAggjmKT4quSokjY2XsRFieGqTcXHT7ihUSkyLGmbeJI33rZxKV6i/OosWuQtR4MYDI0PJcELEHYioFsqbM7bGvXGCKmw79sqrivXRw3cKF4TF5rHWhe0PZ1vGNlK/CqDkcAGZE+eqeYPyMGonmSgyNPpTfhmLChB1p6cmjMM4Bx/gWIwjikP5iRcLB8Kk6BSTy6ailyXZ2r6N7S9nWcayWnRfVCwPEhXMfcb1wHtHwl7BvKZeEEXBHwrTspJ3H00p5Bi5CMUdgB61lLlPVlZsM659JNsytA6j9atiEwAKUcMYleblTkmn4VoXOyH0kTqoM/lBNcm/h/2eONxTmNeuyl1ZQDo4vNI11QmR5mBsRXSeOJUthTaDlW9/TSd05rFfXKJV6UZw3ANsNIZbGVCEhKR0G55k6k8zXFA7An0mq+1TXrJcQ6Egk1XnAXFTR3EHSpWUaVC+MiYGppGZtx+AnKKi/EACwoF5YSJPpRq+dKsQkqN6jYShRcDIUtQ3JMAee1WfhfDCyCCkFR3+woHgeF/qTyBI89PvVqw5sL2/dqfpsIYbj3BzZK4EFRhVcr/ToetE4YkWmvXCQYTF596CdX3YJOp+QqkKqG4kW3EaF0VC9jEoupQHnNVPF8bMwi5+X96nw3Z994hTy8o5an2FhUrfiJcldOu4/YfuZWNEEG7M20ff6Rs9xtg2Lg8wFfpUbWJYXYPD1BH1rZrsrhxrnV5qj6RRLXAsOmD3YtMSSRfU318zWoNaxtwn3gMdKB5S32hDaMmhkVMYNLsaEsoLiCEpAFhcEkxbYelbYbEhdwY+1VhwG2+sScZK7h1DSR61tmEdKj84n96VA4szEU0GJkOIKdRYX+lI+JpmZH/t1uYAg/sU6xC/YUtebhKs0EGbefWvN/EV3CpRgNG4vS4gpAk6TBAn5mtcKpSBmSmB+nP971qlmTtvlmCL/cAUxwyAEFUcyPc/3rwgWZqAqpYzAD3iNPEUTBEGT9aNZdB0qXD8AQ4yor1WorSU6o213NrjSq68l3DOZF33SrZQ6fpSc2kIUPUhyFRkIXqWcJkRQrzOU15w3iKVamDTB5iRzqzQsx4nAwfDOj4Toa1cYLapGm1RFMGmWFUFpymvXTniEYdgMRnT1FKO3HZZGPwxbMBxMqaX+VXIn8qog++oFSsEtrp2hUiarQ7hRiyKnypiMK40tTawUrQSlSTqCDBFZX0vjezuFdWXHGG1rVEqUmSYAAn0ArKKjMsSwYNrKnzvWz6tBzrdSoE0A7iIGb8SiEIHU7+mp6A0ZNCoPfMKaTKidh4R6an3t6VmNdypNStoAAA0FLccvMqBXOaWcO4s4lxEYdAdUM0qAi8meVjp9J8jqxjUvpDiDKVTHoYIjbSq/wBvw8tSWEFGUZViJCkgAhRVsbkRpdXSq/i+1v8AKAJUq60gpTebWkq0Btl5201NQkksVjjtUD3MvuMfQgAKMZiALGCSQAJiAb71sjB1zLina0YjDoICu8QrMJgHIQOUScw1A08qO4T24eSsJWoQAf8AEg5iR4QVjQcjvbnQbgDREvTSM2IOp59Z0PDNZXDyABPqbfT50YrGExNIOzLzjxW6qQXEpgE+EC8ZdtMvzpo/hHUySIHUiPSm4XOy1BokyPMgD7Seo27sEczVX47jCVFtJ0+L9PSrA3iMqIJvFVVTgBWSJKiT1pP4jbqEU1fcp/D8fmLEXXUGwmOKF+BCVnRIKSTPMAHWiDxbFrJh0+G8Jy8wIGX4tdL0ufxyCJSCkj0obC4xaT/TzBRsMs5r7CL+1eAHfF5FY18OP5857h02622i/jzGT3GsSCQp1wHlMfKo08axEz3y/Ukj2NqX4t5Vs8EkA6pJ8V/ERefO9RIdoGy5r4dvqY1dNjK3tX6CNhxBXdLbJBClZovIVIOYbCbiOtNuHYlKF5U/DCd9Ta/SeVVcOU24GgqWOQ/Un70eDPkGRffgfLn/ADEanTqMZPp3/PpLyhZIHO1boPOocOqSSakxDoAtr9K+yXq58m3dQDibiUiSY5del6QrSpRURJnSDb25xTLHjPImYAjoftUWGagQTYeUfLSvM1QOVtp6leIBFv1g2H0y5dlWg2nl0ophd1JMxBjkCIBttpWOPgjwAKOwiPf5UJi8UQMp+KLx9Na8zKyYhGAE8mH9nn5S4L5UrgXkaAmPfSpeK4JLqCkidxzB5iswrRyiFR0gfaKJVhyREmPT7CrceJzjAIkWTzOWEoqcMUnwn9+VPeFY9RhCkE9QbetMF8JE1MzhstDi0hVrh8QLFYa9RM+EzThxuRQDjV6tZa5hA3CH0Z0hQ1FScOd/CajwK9qxacq7U0HpoJ9oyrysSoRWU+LqbYh7OrINN/Kk3BcaMVjHFo/wMKC2g7KdX8ah/pSMv+88qrn8RO1IwbBZQr/qHQZP5E1auwXC/wCXwLLZ+IjOvqtfiVfe5j0oFNtDK0tx+86EpJJgAEk+VVFHapgPJE5gQSFD8xiEkbSDrTntYsjCuhOpSofKvmviOPWhcyQoEm21hy+H5UOUuTSwsKpVtL/2/wC0S+8KkpF4TN/CLgTB0ufeqfh2cKblanFgFSiYyxJtcwm99/vWnDu0BKgl82EqMpF4Gh/e9MUnO8HEITdAzLOWUwZIIymZt/7dRU21gKbuVoEVty1MwwSopdTlC1FIS2oz4RGY5SZgiYnzr0sBxbjSFJISFuNyIJKbraHUJBWP9KqrLnEyVKUFeE3B0JI8uX2HIVY2A+WO8UsIKcpSQfHmJBQcsEpIvOm/Wj8IqR7TMepJJJPJM6l2D4oh3CpAEKbSElI+KwGu5Mb709XxRpKgIGcmLi4850rgXBOLu4Z5LuZQSPCoCJIBNinXw3I9RXa+GnD4jI8ooUTcBKgQTJg63muxZTj/APWfkf7QNRiG4vGb6ZlRPp571X+IYdQUFJvVpW0gjKABOgv8qWt8NWpRKpSnr9hW6rCWrbzN0eo8O7lcw2EKZec2+GLX5+lKX3bkg761dMe0g+FRISBA6/pVfxGCZJEJKUiwvr1J3rydTpOAF9PuZ7Wl1qkkv/BBuEuFUjNCR4jGo00OxtrrapnkMhOgH1opvDtobUlP4t6mwDDKYkZ1f5hYUC4GFJx+5mvqcYYsL+UR9wSoACZ0q2cKw4aQB+I61CtaQcxgcoA+Q2orBrBOa+lh96o0uhXG248+0i1muORdoh7j2RMmsaeJEgwaGb4kM9hMQJtpevX8Ugqj8sWBOsTf9ma9XeKu55Ow+0jxi/xA6axF419bfOlx4qFApTM2Frm9pj96VO8EveBMg3NhvRvD8AhhM2zx4lKE3i3tyrzjuyv5D5fUyi1Ree4ApPdAyTOpJO1/n+lKlvhayoAxYD0/fypxxlOaRrAmQLXuR9fakTDcHptXj61SmTb6TMjkoJdMB8I5RTBKaW8PV4E+VMGlV9PhFoD8JFc3Umo1N1PWhptQoOtNCPN0eRULqawi5oMXoEGi8SmUg1EpFENiUxQKPSETIUOWrK1IFZW2Zk4HgCvHcQa705i68jNP5M0qHllzV9LM/CK+ff4V4YL4i2T+BDq/XKUf/evoQC1Hi6jNR2BOafxJ7XvMYpGHYSlwd2FOIKCTKiYylJzA5ekCRrXPeLYdx2HG2+4Wn4s5kHUyfDEbeKJp3/EVp/CYt5wpTD6irvBPiRoEE/hIAAtymqdheLLccKVBJBkzAKraQVW9KWxayZuLGHIW+T9IcQ2yhWJdSkurlttKE+GbpU6EmJgTA55RzjfgrKHW+9cdKSpXgTlmG0xdQsCSRzOnWoGip8qKjnVZsJMBKGyDqRAT/frTfFsqQjuUrbCYA8LSUqTa4U4CLRyAMmlnJxz3K82MKwROh9ZBjl4V9SkBGRsm5QlIWDzSTpQRbwy1oyrnu4gLOXOfQwkW6zGu9KMUw42sgESBcI0A5+XWgnMLIHiGYkZANDEE7X1j05Vyoe90W2RRxUl4gt3vlF0EGTAtodDaxtFxrVp4NxVxlAVh1BUBMJKjAMRePW28mqzje/yjvB4dlWKRI0BHlp0pjwrDmUKj1H3jWszAFfNCxcMa+86t2O7TNPKSFLHe65bynmCTExp/zV2XjErHxR1riDTCEK7wQkm2aY+dNMHxxbZn4wNQTubySN6QmobGNoFibk0wc7rozo+JUlyUJIUU2NQOobQkJUImLxP73qpjtGgoytpWhRvIjXXWZjWosRxV5ajmiDFieVpjY+VGdQTyF5+0BcB/5S4ZGAQM8zOnSP36V7inGkDKIKucwB5mq5wriKEphaVFU67ERy2N9a1e7t0nJZzkbZto9r1P+ZZT5gI0afd0TLGzhGzCu9S4NyDbyFa4vFgJWluM0QADeTz5etIcLwFZmyRKhYkW6840t8qdpyt21N/7wOVa2ssbQtXBOnCmy1xMx/NKt3ZSkbkwPp9KYN4J8kqABJjXwx7i9SJx0myRsPbapk4u3XqT/akDG5/2f+4TZlHVR3wjKhOX8X4p1nr9qIec059darjXF0qvyi4/elSYjiHh8JPnHOqF1LINpWTHGGN3POOGElOl5JzXOnqf0FK8CCs2uf3egcXhXFwmRJ84A5noAKaMPhtISj3Op/zHz+QIqR8PjvubgTMtABV5liwYCUgE3HKjEufuaSYRydaZtGvWxOAoAk+yGhZ5/v2r3PzqBKq3BqgGZUmTetFivBWyVc62dBHBUmHr1wVjAvQgcwpCtFzXtSupuayuqdc5D/CNj/rVHkwv5uND713FNcd/hWwU4hxW3dR//Vr9K7CNKHTta3G6kU8Q9teCpxTJQQCYVlJ2MVwjtN2SxDCQe7OXNlBA52Fta+kMSLVU/wCILhTh0nIVNKJS4U6pkQk6WEyZ6CtyCvMIGI//ADOScVxqMKhLLDalkAFSjHh2lJy/ETvr6QAHgeJqUlaXnMi1ZChRkogSC2sC6SfiB0nWJmoMXhzlSnPmUpwym8biFKO0CtO1KCkIShKVgiVOAyc5G9hAjQb0kU3B7lIBQE+kXYtZuCohIjkCopJsra36Uw7PNh1wKcWITmhG5KgRA5X3obhmKjIlbSXFGAkFMkyI0i8fYcquXDMOywgZWUF05u8UEQhOhhOaM2wgCBrWZH2LVQzjDZNynjuCY3CYdpJRK275iMwUMyUqBuqYsVW39KU8KxSYWcwyScs6yPteK04m2X1qQJhJUoKXqQR8MdDvR2K4fhkIaKAogoBUToHEznTMATbz0jWgoFee4TNtb4Re9jFO+EmQNhHMgfSoGXC24IVPMcxuKkdSl4lTbPiNk5SqDNiojYDzjWiP/R8jXj/zEyfa+1vnREKBBVmMITjspzBUiPasTxxySLA/O+lLGYsgzad9RJ1PlUeJWGlRHhP7FdXpN47MtOG42FKAMiBN9+s1Z+HYkKE1y/B4oFRSLm50mR0NH8M44topSApRmIOo9aE474IgN1YM6I9xDLKcwSReLXH1FLEcfzK1KlaWiABVX4nxRTi+QIywN7bn3vWYVzKSlXIGZ+VIbGF5UcwkBb9Rl1a4u2oHKsgQZURodJvrRvDsQFolJzDSYi41sfOqMcRlzDZRgel4HtTjs5xdtptWckzBAT8MabmyufkK6z2YLYeOJam8PsLA7CmbLFqQp48zmTc3HLTe+/tNWDh/EGnPgWknlofY3ijxlTFFGHYni8MIM6AX8tSPlVbxbqypYbu4lOcJOgkyLkjraatOOXCXI1yn/wCJrj2OxanHCpalakRYEJmctove/n7ZmHFCU6TCMh59Jacf2mHdjKHUqEKgwnTfW41trpfegVYxXdB9p5QXIKkBwgpknTaBOmgBqtyov9zhypSVlITmIvYWOgsZ9qnc4QWnFNvNnOm/hIIIMQZmIN760g4gvIJ957uLDixjynv09anQuz/bBKWkB50qVoc0AiOoGnnJq7YHHIdTmQqRY+h0Pl1rimGdC0ZUtqU5mASQCfDumNdKsnB+NpYDTaszbiVKlSvhEhWVJ1MSRbS2tbj1GTG3PInm6rQAgsvdzqAral3B+KN4hvO2oEAlJgyApNiJ+Y6EGmIr1lNixPFZSpozVYmvGda9NSMprfWDIndaytndTWVtTpzzsPhy2+rxAgtKFuikK/8ArXT2TIrnXBCEuoOQCTlmNleH71fuHueAe3taovw9rx18ZVrP13CHE2oXH4fOw4jXMlQ9xR4rRvUiryJGDU+Y+IqKXFhRIMqkQQUmbR1ofhwQ+e7WpKTMlwlUkJEkQDlJMb+l67T2/wCxDeJBcSnK7zH4vPrXHTwgtPpQvU5oSAZMJUQPUiOt6mYbeDKg+7qOVqwzBU+DdtKUpFvFm/GmCRBg6c71WXu0a1lUFSQTYA/DbYGQR+5p3/8Aj3eAJxWZlf4QIgk6dNAOW9K+LdnQ2k93dSNdbiPiPLTalo2O6buPG8AUOIXgGCpkvN4kZh4VNqCiRO5AScqTYaETvQI4c+kKhxJCpM50xKgdklRm/KTNK0PkEKR4bAHLPKDPnv5mmjilGMoI038WaOXmaY3l6lCYcWUUxIP2lgPBVNshaHnJUQSohJBREkpCdACbAnavcTwtJZIK1uLUmUqkhIJG4F40mZpVw3iuRGRRXZQIyxl6ggkRJA0I3o3GdpVZgQBKoKoshUCVAJKZF9TmvA0qdw5PE7wggPt1K3i8GpJtHhMeDmORNQJcLhAUMx6DYbmKIClvhRSkpSCSo2AuYITe/kK9wqHS6oNtqUPhUUi/KTJgX51ULA57kDMu6luasIgqCEqzwIA2I89iKmW4rNlQAp02UofQE/M054Pwla2itUpUmR3cAKOQ/CVToYmAL2o5vjmFK8qxqfxDMFcp3mY2qdsws0Ljkwlhd1FA4DicneBBUOSJkWNiIHymoBw/ELAmQAZgxYfe4q6cSxxQkpC1JF5AMWI0/vSDCcSN0qFwNxqAdudyKSmZ2s0I5sK8WYOrxKKXUZSnIUGbEzrItfka2dw+RQULn4oGl9U60W5im1AyBA0IAEHQGPf3qDCFJLqfBBVImCCOeXkeVZuuGMZo8yUY9pTiQi0Amb7m/wA6Z8I40hrEJUuSEhREETJBE+UTbrSJWDKCO6AA1PkbwOloio8ThXFEFPMm+qTb3n7UQQFrEAk1RnU2uONOkFBMWChEKE6H/iuWcXCkPOJXIUFqSZ1MEwesiL70VwXEOMugruk+FXkYk+hv6U87W8NJAxKBKkAB1OspA8LkbgAAHoEnY00ruHxEp0WzHk2t03XwMqmDwSlhakz/AE0ldrGRpHlc/wC3nFFtuqZyq705yBIUjMESNyTfXYc/UJOKMwJyqgKCTGa+nrUzvFFd4HEGFTOlo5RoRFJ59RPa8EC+Y8YwbTzgOHxndylRVnzIJVpAKUgCeXSk+MPiJWcxFlKmcxgmdYna3KaAQ4RuRN/eiGilU5jMwZM3O/kdKHbUVjDA9n+/1l5/hhi3EP8AdlK+6dSSk5V5cyBqPwgkanoBXVq5f2NXiJwnhHcBbgBSmTGVUZ/EIEg3jl5V07P+/wB2qzSksp/efP8A4mbzk8fL4cT1Y+1SspqF/UDqPYf8fOidE1SO55pgq03Ne17XtdOqVNt7pVj4W8DPJUKHr/eaULK+Sff+1TYF8iCQBBymDsq4PvPvXlaF9rbT6yzUCxcs6a9VzqJtVTJr2BITEHaLg2IfUS3ilNIgWQLiNfMk7k2G15FAxvYhxpw4h93+aKfEnMCCCNzBv05V19PKq92sYUWHAlRSQnMD/pvHkYpWZLUmFjrdRlNwr5eazuhKgT4W4T4ROUq87TzpNxnijKCUhQUJypEjNGgkkADfwxakmL4y6TMwsWJE380zHypThMMFPKcxCs1wrSSrkmD5dbV5yIa5/wBz0XISqFzziXAXhiULbaPclSDmQPDBVMHlFulgasj3DWkKIDJKlqsuSQCSDNrZBNoG29M+GPIWFJJQpWxFoj8Co2gyP+KW8exRaBBbSUKBSQmRHO0a9aFsz5No+sbjxjHdfKS4hGBQhQBGaBJuVnfUiw6AUt4c+13jJyNhvvFqBKLlQkQTz3E3sY0quPpKoU14jMpEXMXI8+m/rTBPEFgJhAKZkJKRJUEwSlcSDCxYHYbin+EqiSYMuXNm2E/KXXFYrC4hJQQJSTMSCmLTmBvpNJ1vsNrJSnxKspSSRPIAbR01qrcRxQSRklIOXMJ2kEg87/Sh+J4d2ZJIWk+ETOYg2KdiLx70CYSe24lWXah/TzLcvi7i4AiE/wCXoeX1NasLaKEoCEIfUkKVIAK5JIIMXMmYPWlbTvcMJUpf9UZSY1BgyCncaT60K7j8Rjm0NkAKCgsLjkFiIA6j2oEwgXXXvBG0HcBzXUIx7xLuR1aVRcqBixG6fvU2Mwk5A34iq4vYAbjp+vWh8HwRWdYfKVKtCtwIEeGNKld4MtKwttWVIEAg+FUEmCOUgnfXrRkqCBf+J3mIupvxHhTyWZTCiLuCLq0IKY1NV/iWJ/wiJmCDG4tA+tWPEcdiQCCRII5bb6CocBwvDkB1CSYi5JOVQN49Rqa1W28uJzru4UzTCfzIylKRk8N12P8Ax06VMvjSAuHGwCIukDKAeZ3M007xElJ+IBJ6QeY9akZYQo5VBN5AEHxDcEXtSd4PYhhSPWCYjFJU14EymBBBvbnzojs/2hjK2u0CErOgGgQoctp/5pOvAuYeVJIW2okCfiEE2UJjNaJvMbUy4Vwrv0KWPArNuOliRNqYp2ncvMcyps83X9DHON7MNqQoNJyySvJyURH9M/liTl6mNgKdxVhCHA0lOUtgJUqbrV+Yg/D5VZcLxF5hYaUnOm1hqB/kVE+/y1pqp7D4lWR1AKwAYcSUOJHIOCxHSYogqubBo+3pH4NQ2Ejf5l9x3KW3wB91WRtGZZBX8QuAJME76WrXB4NSnW2MqkkkBQKTYT4lKSdQkZiZ0g6VfWOzLaTmbcfbuCIhQBFrEQdJGuhNO2MEgNFkhS2yT4Sm5BOYhS1qUpV76x0rVxPdHqOy/imND5OQR7VX+f5zJODIbkFqO6RIQQmEqJ+JaQZIBsLQDlnerG2YudeXL98qW4HKkQlITAAHMem3pR7dV4kGNaE+cytvNwlgSZqd9W1R4cQKxN1U2JkiWxWVinayuqZcqbjY/wDGPUj9ajwSgHMpCEhYy2Vefwn3+tTrDf5FH0NBvAbNH2Ar5vFk2MGnqMLFS0cKxBKYOosfMUzQaquCxnwukRPhWJ0UND6j61Zm1Tea+ixuGFieYy0aMINBcawXfNKTzBHKaMQa2FMIBFGADRufO/bFlzDLUnuoSTYqBzJP+r8Q8/nVTHEj3qSsQEqv62J62mvo7twhnusqmu9cX4UIAuTztcAdK5NjP4e4gnvHLJgCE/FAG4tHzqfaq3cd4jNXMW4DEoUf6ZQRPiIVBg7W3/Ss4niTkuYmRPQAW6167he4bLTaTMzJ3PntFVJWPUpXjPh6a/rFTLh3mx1LTnCij2Yy4YFKe/pkkRJ11BGW/wCE3JB87Xp0cKlxSkLSCJJAAi9zBggggH25xQuH4i00lIZCUJnMbzJPMm5ta/SgFv8AiLiNZ8QVcGL6/eiNsfhEPiB8wPmgnF8L3K1IINpB6H+4uOYotfF+8w6Cr/EbEJJ/e/2ojGMBXduhaT4k2cIvAskzrEC2hT7UZx/iGHIypSlSwUlKglI2BsU2j7UZPQq4aEmySBFKXHXoKklMG6lAwQL250XhuN5AMqcqt+UdD+9a2fx6HkXUEg2gqyiY6AzPWk/EkZVBKFBUixQVKm+gJAM+QiuCh+CI6tq7ruWPG8bC8qFuJJseUZtQpQ23pevHGIaUgJvAnmeR01pMxwd5agEoJJIB18M28XKp3eEOMLWhwDQQZsUyRmEc+vKu8HGOLgDO3tPXmW1EqEoX/qChO9tR7mKI4ZjFhSWomJnLy1nlUaygBIETI2uZHTUU+4ewpwp/lwBlhStQFzaNI5i+lY7CueoVg/p4MV47HOZ1QFQcoSFJg2vChtv6Cjl4ha1BaomBCQTGmo5VZ28ShJ7paMvhuFQZ69dTVf4zwhKf62HUcsjMkkm+nhJm16mXKrGqqE2Nl5PM3TDwSIywIIuBbS0edEOYEtI71pwpKfi3SpO9uY199684OpxKFZmgATOaLxz186N7ReAIQrQnNHMDYjzI9q0ccCEuQg3NOHhbgJMlQ0VmlO5m97+VbYfDPNLLphaifF5co9B8qGGKHetJKilpZCbCJ6dNQNqe4pn40pXcEgfTT396W5rmGCrEgRwAdqJwzCjuam4ThpSNFXMRy2FPcLgY1qlFJ6kbELxIcDh6bMt1jbWwqYGBVSLUmY3PHDaK9FhXjY3oHjGLKEHLGc2TJi56wb8huRFET6wfhB8Rx5lKinxEgwSkEiRqJ6G3pWUs75lvwd0XCNVhQhStVG6uc1lDZhUPYyQYxKvhObyKPsaienkPVR+wrnbnZhY/7RHkB9qgPCXE6d4PVf6188An/L7T0qPtL+xiQ2ohZT3axCunJXp+tWHhGKKCWlm40PNOxrj3dPp0dcH+4/cVbeyfFFOIGHdX/XRJZWY8aRctk7kD5DpXo6PKB5Cf2k2fHfmAnUUKqcGaR8J4jnEGQoajrTZpdeorSEieDBthwu5RnICc28DbpW7zAVrUgNbCjAEGzOfds+xgeSVtghQuIJF/SuJY/hzhAQtOVbYUhSbA5syjMRMEmfWvqxSZqqdq+AIdHeBCO8AIkjUaxIvsPalOhWysO93E+deHcOXm7tYi5+WoroGK4G2tpKQkiwHhA8BI1I/F69aFTwBbr5hCmwiS5I8O/wAKtL8+W1HcVfWkJCHE7SAbgWJkEXA3ivPz5TY956Ojx7hzKJi8K63OcZUErQnMDlUUkpjTTw6+R61HjMOtxUqWkLMCBmVKoFiQmJPSavHFmR/LLVBeQlOYqWLHW6CLGN4O4pd2e4y0pYKUra8MBJuMw/KfQ3PTrTRnat1dSbJhIcID3BuzvZhxrOrEISApOVKSZN5k2300M3orH8ELKkqw6QQrNmKohsAazrBPnrVmdxqRhwsGCfCQIsJjffeqfi+Ou5yEK8HwjMAZ6nb/AIBqZcr5XJl/hqigSxcK4eppCSAXMx8UR4bXi4sDHX6UL2wLZaDmUKVISCVQpIUrSwvoLfpTfBcQAbVChCRPvt5k0pzpd/xEgeIKhY1F/tp60tXtrhshAoyqt5BokAkjXXYGPSjWuKEQylOVOZWYjW4tbdGt9bV5xTAOPuhLYyIMyuJBAgDL86ExnBMQ2vwBTiYEKBGaBsRa9W7FdeZBkZkyWIzzD41LKyPzaCDoOVL3OLygEgBEk2FuhPi1pHxDCvk5ilZA3M2n6UJhlr+EXCiNdPnprTU06jm7i31DHgWJdMD2rQUhsoJ/zAwT++VM+Mvd6wyto94WkwoifCVQQkzrEAT0vVPPDsjZkGUqMQJm8QR73FWvsE06l5Lah/SeEHQwoJJTO4Oo9fKlviQC1mY8zk8wJo96gm5yEKCZg2iD03vT9/HZh4bAZZJN568qY8R7KZVFbQgmxA3nWo+HcGdQoDIT1/WpXxE8S5cwHNcy49iWEDDghROYkmdiISR8vnVkQilvBsMpKAnKEjkBAv0pnEV6GJdqASHI25iZuSBUaEFV9q3aw83NRcRxyWk8zoEjUk/SmfvF/ATTiGMQ0nMowBp1quPLKlFzKS64PAP/ABpAIkXsSSQFcr2kyZi3jmzKTmcvkTHwGwzSTebEJPP3EWFtTnUlbqzCYmUzqJP2iwAvFAxhdSEYZlMpdyqWCZNzNzFzeYiayq7xDtZgWHFNOZ1uIMLUkSM2pAM7G3pWUNmZbRaz/Elg/E2sf6VT9Yohvt3g1alweYSfoo1x+a8mkH8NxHq4z8207Ke0+DV/3CPNB/Sh3uK4cwUOpBBBB0II0INr1yKa3S4difeh/wDGKDYYwvzh9RO/8H4wMR421J79A8aUkQ4kfiH7sat3CeIpdHI7jcGvlzBcUeaWlxtxSVpMpUDodN7HlB1rsHZPtSnGDMiG8UkS41olwDVaOY6aje0E2BWQc8yckMeJ1hKqkSqkHCOMhwQbKGoOtN0rmjVphEKrVxsKsRUaVxUqVg0wEGBVQDEcPscutcq7U4Tu3StbURsE2XY76g/2612aoMRg21/GkHzpObTjIOI3FmKTgPEMbisS0Gg2Q2NQnUj8pHLpS13gziAClJ0nSCDX0R/6OyDIQAelC47gDbguKV+XZRxHeOCbM+flBbgHNNiOfUjnRrGDAjMnMAZuPbzroPFv4dqzFeHUEqPP4T5ilSeA4pojMwu26RmE8xG2utTOrr6SzHkRxyeZT1MrC85SDEnIqQIM+1G4TCOvOKEgifQaaAnS0elWvD9lXlnMtBCeutWPhfZ5Ld8t61MZPJEDJnA4WJOFcDWlMFIPPrRC+BR8KRa9XJnC9KnDAG1MOnBEmOUygYjsypaVDKIIMiueM9l8WlSm04VxSUq8RAKQd4zGAQedfQakQUwCZMW0FiZPS0eoqXuZ2o0wBRQi3fceZwbhnDnlOIYKcji1GQqVZTM5zGtt966JwXsMhtaHXHC4tJkADKgK5xJJPmaccc7PErRiGgC8yrMkaZ0/ibn/ADAkdCfOrBhoUlK4IkAwoQRImCNj0o1w82Z3i0tCCpwQO1TtYJI2FEk15T9gEVuJkZTyrA2Bc16pwCoHHazgTuZut2l2PQYKkAZwIBtMXsCbb/WiCulfFOKBsRqo6DrQMwrmaOJA+6lgFRMuLMxG52AvGp33NUTtv2nOGSUpP/VOD/8ASg79Fnb35ST2q7SjCJzrheJUP6beyAfxr+w39zXHsZiluLU4tRUtRJUo6knehRS5v0nM1SNS+tZWlZVVRVmRmtTXtZWTZ5XorKyuM6ZRXCnlIfaUhRSoONwUkgiVAGCNLEj1rysrpo7n0DxcQ8kix6VasAo5RWVlSr3Gw0GthXlZTYMIRW1ZWU0dRc8Fe1lZRLOmVqqvKyhaaJrFaoFe1lBCnh+KpKysrBOMxNet6V5WUawTN60NZWVrThPRXjlZWUPpOgy6gVWVlLMZB8SfCaqnD7vqm+ute1lJydzJw7jzqlYl4qUVHvHLkkmyiBc9AKXKrKyq06i27mVlZWUcGf/Z',
                width: 300, // Image width
                height: 200, // Image height
                fit: BoxFit.cover, // Ensure the image does not stretch or distort
              ),
            ),
            SizedBox(height: 50), // Space between the image and text
            // Text describing the steps
            Text(
              ' ผัดกระเพรา เป็นหนึ่งในเมนูอาหารไทยที่ได้รับความนิยมมาก ด้วยรสชาติที่กลมกล่อม เปรี้ยวเผ็ดหวานจากซอสต่างๆ และมีกลิ่นหอมของใบกระเพราที่ทอดจนกรอบ ผัดกระเพราเป็นอาหารที่ทำง่ายและรสชาติอร่อย โดยสามารถใช้เนื้อสัตว์ได้หลายประเภท เช่น หมู, ไก่, เนื้อ หรือทูน่า เป็นต้น',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          
            SizedBox(height: 20), // Space between text and buttons

            // Like and Dislike Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Like button
                IconButton(
                  icon: Icon(Icons.thumb_up, color: Colors.blue),
                  onPressed: () {
                    setState(() {
                      likeCount++;
                    });
                  },
                ),
                Text(
                  '$likeCount Likes',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 20), // Space between buttons

                // Dislike button
                IconButton(
                  icon: Icon(Icons.thumb_down, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      dislikeCount++;
                    });
                  },
                ),
                Text(
                  '$dislikeCount Dislikes',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 20), // Space between buttons and the next content

            // Center the "Open Page 1" button
            Center(
              child: ElevatedButton(
                child: Text('เปิดหน้าที่ 1'),
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
              ),
            ),
            
             Center(
              child: ElevatedButton(
                onPressed: _launchYoutube,
                child: Text('ดูวิดีโอ'),
              ),
            )
          ],
        ),
      ),
    );
  }

  // Method for creating step text
  Widget _buildStep(int stepNumber, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Text(
            '$stepNumber.',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

